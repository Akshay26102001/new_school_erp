<?php

namespace App\Policies;

use App\Models\User;
use App\Models\School;
use Illuminate\Auth\Access\HandlesAuthorization;

class SchoolPolicy
{
    use HandlesAuthorization;

    /**
     * Determine if the user can view any schools.
     * Only Super Admin can view all schools list.
     */
    public function viewAny(User $user): bool
    {
        return $user->role === 'super-admin';
    }

    /**
     * Determine if the user can view a specific school.
     * - Super Admin can view any school
     * - School Admin can view their own school
     * - Teachers/Staff can view their school
     * - Students can view their school
     */
    public function view(User $user, School $school): bool
    {
        // Super Admin can view any school
        if ($user->role === 'super-admin') {
            return true;
        }

        // Users can view their own school
        return $user->school_id === $school->id;
    }

    /**
     * Determine if the user can create (onboard) a new school.
     * Only Super Admin can onboard new schools.
     */
    public function create(User $user): bool
    {
        return $user->role === 'super-admin';
    }

    /**
     * Determine if the user can update a school.
     * - Super Admin can update any school
     * - School Admin can update only their own school
     */
    public function update(User $user, School $school): bool
    {
        // Super Admin can update any school
        if ($user->role === 'super-admin') {
            return true;
        }

        // School Admin can update only their own school
        if ($user->role === 'school_admin' && $user->school_id === $school->id) {
            return true;
        }

        return false;
    }

    /**
     * Determine if the user can delete a school.
     * Only Super Admin can delete schools.
     * Note: Soft delete is recommended for data integrity.
     */
    public function delete(User $user, School $school): bool
    {
        return $user->role === 'super-admin';
    }

    /**
     * Determine if the user can restore a deleted school.
     * Only Super Admin can restore schools.
     */
    public function restore(User $user, School $school): bool
    {
        return $user->role === 'super-admin';
    }

    /**
     * Determine if the user can permanently delete a school.
     * Only Super Admin can force delete schools.
     */
    public function forceDelete(User $user, School $school): bool
    {
        return $user->role === 'super-admin';
    }

    /**
     * Determine if the user can activate a school.
     * Only Super Admin can activate/approve schools.
     */
    public function activate(User $user, School $school): bool
    {
        return $user->role === 'super-admin';
    }

    /**
     * Determine if the user can deactivate a school.
     * Only Super Admin can deactivate schools.
     */
    public function deactivate(User $user, School $school): bool
    {
        return $user->role === 'super-admin';
    }

    /**
     * Determine if the user can verify a school.
     * Only Super Admin can verify schools.
     */
    public function verify(User $user, School $school): bool
    {
        return $user->role === 'super-admin';
    }

    /**
     * Determine if the user can manage school settings.
     * - Super Admin can manage any school settings
     * - School Admin can manage only their school settings
     */
    public function manageSettings(User $user, School $school): bool
    {
        if ($user->role === 'super-admin') {
            return true;
        }

        return $user->role === 'school_admin' && $user->school_id === $school->id;
    }

    /**
     * Determine if the user can view school reports.
     * - Super Admin can view any school reports
     * - School Admin can view their school reports
     * - Principal can view their school reports
     */
    public function viewReports(User $user, School $school): bool
    {
        if ($user->role === 'super-admin') {
            return true;
        }

        if (in_array($user->role, ['school_admin', 'principal']) && $user->school_id === $school->id) {
            return true;
        }

        return false;
    }

    /**
     * Determine if the user can manage school staff.
     * - Super Admin can manage any school staff
     * - School Admin can manage their school staff
     * - Principal can manage their school staff
     */
    public function manageStaff(User $user, School $school): bool
    {
        if ($user->role === 'super-admin') {
            return true;
        }

        if (in_array($user->role, ['school_admin', 'principal']) && $user->school_id === $school->id) {
            return true;
        }

        return false;
    }

    /**
     * Determine if the user can manage school students.
     * - Super Admin can manage any school students
     * - School Admin can manage their school students
     * - Principal can manage their school students
     */
    public function manageStudents(User $user, School $school): bool
    {
        if ($user->role === 'super-admin') {
            return true;
        }

        if (in_array($user->role, ['school_admin', 'principal']) && $user->school_id === $school->id) {
            return true;
        }

        return false;
    }
}