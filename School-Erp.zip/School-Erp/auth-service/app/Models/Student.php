<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Student extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',      // reference to users table
        'parent_id',    // reference to parents_profiles table  
        'full_name',
        'gender',
        'date_of_birth',
        'blood_group',
        'aadhar_number',
        'category',
        'religion',
        'nationality',

        'admission_number',
        'admission_date',
        'class',
        'section',
        'previous_school',
        'last_exam_result',
        'student_roll_number',

        'mobile_number',
        'alternate_mobile',
        'email',
        'address_line1',
        'address_line2',
        'city',
        'state',
        'pincode',

        'photo',
        'birth_certificate',
        'aadhar_card',
        'transfer_certificate',
        'remarks',
        'status',
    ];

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }

   

    public function parent()
    {
        return $this->belongsTo(ParentsProfile::class, 'parent_id');
    }


    protected $casts = [
        'admission_date' => 'date',
        'date_of_birth' => 'date',
    ];
}
