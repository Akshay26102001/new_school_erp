<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class School extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = 'schools';

    protected $fillable = [
        'name',
        'display_name',
        'school_code',
        'registration_number',
        'school_type',
        'education_level',
        'founded_date',
        'description',
        'status',
        'address_line_1',
        'address_line_2',
        'city',
        'state',
        'postal_code',
        'country',
        'phone',
        'email',
        'website',
        'principal_name',
        'principal_email',
        'principal_phone',
        'board_affiliation',
        'medium_of_instruction',
        'created_by',
        'updated_by',
        'is_verified',
        'verification_date',
    ];

    protected $casts = [
        'founded_date' => 'date',
        'is_verified' => 'boolean',
        'verification_date' => 'datetime',
    ];

    /**
     * Dates for soft deletes
     */
    protected $dates = ['deleted_at'];

    /**
     * Relationships
     */

    // Example: A school may have many students
    public function students()
    {
        return $this->hasMany(Student::class, 'school_id');
    }

    // Example: A school may have many teachers
    public function teachers()
    {
        return $this->hasMany(Teacher::class, 'school_id');
    }

    // Example: A school may belong to a creator (super admin who onboarded)
    public function creator()
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    // Example: A school may belong to an updater (last updated user)
    public function updater()
    {
        return $this->belongsTo(User::class, 'updated_by');
    }
}