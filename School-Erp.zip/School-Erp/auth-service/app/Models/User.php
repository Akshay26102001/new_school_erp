<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Tymon\JWTAuth\Contracts\JWTSubject;
use Spatie\Permission\Traits\HasRoles;
use Spatie\Activitylog\Traits\LogsActivity;
use Spatie\Activitylog\LogOptions;
use Carbon\Carbon;

class User extends Authenticatable implements JWTSubject
{
    use HasFactory, Notifiable, SoftDeletes, HasRoles, LogsActivity;

    /**
     * The attributes that are mass assignable.
     */
    protected $fillable = [
        'uuid',
        'username',
        'name',
        'email',
        'password',
        'phone',
        'mobile_no',
        'role',
        'school_id',
        'is_verified',
        'is_active',
        'last_login_at',
        'last_login_ip',
        'failed_login_attempts',
        'locked_until',
        'password_changed_at',
        'must_change_password',
        'otp',
        'otp_expires_at',
        'email_verification_token', // Added this field
        'two_factor_secret',
        'two_factor_recovery_codes',
        'password_reset_otp',
        'password_reset_otp_expires_at',
        'password_reset_token',
        'password_reset_verified',
        'password_reset_verified_at',
        'temp_reset_token'
    ];

    /**
     * The attributes that should be hidden for serialization.
     */
    protected $hidden = [
        'password',
        'remember_token',
        'two_factor_secret',
        'two_factor_recovery_codes',
        'otp'
    ];

    /**
     * Get the attributes that should be cast.
     */
    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'last_login_at' => 'datetime',
            'locked_until' => 'datetime',
            'password_changed_at' => 'datetime',
            'otp_expires_at' => 'datetime',
            'is_verified' => 'boolean',
            'is_active' => 'boolean',
            'must_change_password' => 'boolean',
            'failed_login_attempts' => 'integer',
            'two_factor_recovery_codes' => 'array',
            'password' => 'hashed',
        ];
    }

    /**
     * The attributes that should be logged for activity.
     */
    public function getActivitylogOptions(): LogOptions
    {
        return LogOptions::defaults()
            ->logOnly([
                'name', 'email', 'username', 'is_active', 
                'is_verified', 'school_id', 'mobile_no'
            ])
            ->logOnlyDirty()
            ->dontSubmitEmptyLogs()
            ->setDescriptionForEvent(fn(string $eventName) => "User was {$eventName}");
    }

    /**
     * Boot the model
     */
    protected static function boot()
    {
        parent::boot();

        // Auto-generate UUID when creating
        static::creating(function ($user) {
            if (empty($user->uuid)) {
                $user->uuid = \Str::uuid();
            }
        });

        // Log important security events
        static::updating(function ($user) {
            if ($user->isDirty('password')) {
                activity()
                    ->performedOn($user)
                    ->withProperties([
                        'ip_address' => request()->ip(),
                        'user_agent' => request()->userAgent()
                    ])
                    ->log('Password changed');
            }

            if ($user->isDirty('is_active') && !$user->is_active) {
                activity()
                    ->performedOn($user)
                    ->withProperties([
                        'ip_address' => request()->ip(),
                        'deactivated_by' => auth()->id()
                    ])
                    ->log('User deactivated');
            }
        });
    }

    /**
     * Get the identifier that will be stored in the subject claim of the JWT.
     */
    public function getJWTIdentifier()
    {
        return $this->getKey();
    }

    /**
     * Return a key value array, containing any custom claims to be added to the JWT.
     */
    public function getJWTCustomClaims()
    {
        return [
            'uuid' => $this->uuid,
            'role' => $this->getRoleNames()->first(),
            'school_id' => $this->school_id,
            'is_verified' => $this->is_verified,
            'permissions' => $this->getAllPermissions()->pluck('name')->toArray()
        ];
    }

    /**
     * Scope for active users
     */
    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }

    /**
     * Scope for verified users
     */
    public function scopeVerified($query)
    {
        return $query->where('is_verified', true);
    }

    /**
     * Scope for specific role
     */
    public function scopeWithRole($query, $role)
    {
        return $query->role($role);
    }

    /**
     * Scope for specific school
     */
    public function scopeForSchool($query, $schoolId)
    {
        return $query->where('school_id', $schoolId);
    }

    /**
     * Check if user account is locked
     */
    public function isLocked(): bool
    {
        return $this->locked_until && Carbon::parse($this->locked_until)->isFuture();
    }

    /**
     * Check if user needs password change
     */
    public function needsPasswordChange(): bool
    {
        return $this->must_change_password || 
               ($this->password_changed_at && 
                Carbon::parse($this->password_changed_at)->diffInDays(now()) > 90);
    }

    /**
     * Check if OTP is expired
     */
    public function isOtpExpired(): bool
    {
        return !$this->otp_expires_at || Carbon::parse($this->otp_expires_at)->isPast();
    }

    /**
     * Get user's full display name
     */
    public function getFullNameAttribute(): string
    {
        return $this->name;
    }

    /**
     * Get user's display name with role
     */
    public function getDisplayNameAttribute(): string
    {
        return $this->name . ' (' . ucfirst($this->role) . ')';
    }

    /**
     * Check if user has two-factor authentication enabled
     */
    public function hasTwoFactorEnabled(): bool
    {
        return !is_null($this->two_factor_secret);
    }

    /**
     * Get masked email for privacy
     */
    public function getMaskedEmailAttribute(): string
    {
        $email = $this->email;
        $parts = explode('@', $email);
        $username = $parts[0];
        $domain = $parts[1];
        
        $maskedUsername = substr($username, 0, 2) . str_repeat('*', strlen($username) - 4) . substr($username, -2);
        
        return $maskedUsername . '@' . $domain;
    }

    /**
     * Get masked phone number for privacy
     */
    public function getMaskedPhoneAttribute(): ?string
    {
        if (!$this->mobile_no) {
            return null;
        }

        $phone = $this->mobile_no;
        $length = strlen($phone);
        
        if ($length <= 4) {
            return $phone;
        }
        
        return substr($phone, 0, 2) . str_repeat('*', $length - 4) . substr($phone, -2);
    }

    /**
     * Check if user can perform action based on role and permissions
     */
    public function canPerformAction(string $action, $resource = null): bool
    {
        // Check if user is active and verified
        if (!$this->is_active || !$this->is_verified) {
            return false;
        }

        // Check if account is locked
        if ($this->isLocked()) {
            return false;
        }

        // Check permission using Spatie
        return $this->can($action) || $this->hasRole('admin');
    }

    /**
     * Get user activity logs
     */
    public function activityLogs()
    {
        return $this->activities()->latest();
    }

    /**
     * Get recent login history (you'll need to create a separate table for this)
     */
    public function loginHistory()
    {
        return $this->hasMany(LoginHistory::class)->latest();
    }

    /**
     * Relationships
     */

    /**
     * If this is a student, get student profile
     */
    public function studentProfile()
    {
        return $this->hasOne(Student::class, 'user_id');
    }


    public function parentProfile()
    {
        return $this->hasOne(ParentProfile::class, 'user_id');
    }

    /**
     * If this is a staff member, get staff profile
     */
    public function staffProfile()
    {
        return $this->hasOne(Staff::class, 'user_id');
    }

    /**
     * Get user's school
     */
    public function school()
    {
        return $this->belongsTo(School::class, 'school_id', 'school_code');
    }

    /**
     * User's sessions (if you track active sessions)
     */
    public function sessions()
    {
        return $this->hasMany(UserSession::class);
    }

    /**
     * Security Methods
     */

    /**
     * Lock user account
     */
    public function lockAccount(int $minutes = 15, string $reason = 'Security violation')
    {
        $this->update([
            'locked_until' => now()->addMinutes($minutes),
            'is_active' => false
        ]);

        activity()
            ->performedOn($this)
            ->withProperties([
                'reason' => $reason,
                'locked_for_minutes' => $minutes,
                'locked_by' => auth()->id()
            ])
            ->log('Account locked');
    }

    /**
     * Unlock user account
     */
    public function unlockAccount()
    {
        $this->update([
            'locked_until' => null,
            'failed_login_attempts' => 0,
            'is_active' => true
        ]);

        activity()
            ->performedOn($this)
            ->withProperties([
                'unlocked_by' => auth()->id()
            ])
            ->log('Account unlocked');
    }

    /**
     * Force password change
     */
    public function forcePasswordChange(string $reason = 'Security policy')
    {
        $this->update([
            'must_change_password' => true
        ]);

        activity()
            ->performedOn($this)
            ->withProperties([
                'reason' => $reason,
                'forced_by' => auth()->id()
            ])
            ->log('Password change forced');
    }

    /**
     * Reset failed login attempts
     */
    public function resetFailedAttempts()
    {
        $this->update([
            'failed_login_attempts' => 0,
            'locked_until' => null
        ]);
    }

    /**
     * Generate secure password reset token
     */
    public function generatePasswordResetToken(): string
    {
        $token = hash('sha256', \Str::random(60));
        
        // Store in password_resets table (Laravel default) or custom table
        \DB::table('password_resets')->updateOrInsert(
            ['email' => $this->email],
            [
                'token' => hash('sha256', $token),
                'created_at' => now()
            ]
        );

        return $token;
    }

    /**
     * Utility Methods
     */

    /**
     * Get user's permissions as array
     */
    public function getPermissionsArray(): array
    {
        return $this->getAllPermissions()->pluck('name')->toArray();
    }

    /**
     * Get user's roles as array
     */
    public function getRolesArray(): array
    {
        return $this->roles->pluck('name')->toArray();
    }

    /**
     * Check if user belongs to specific school
     */
    public function belongsToSchool(string $schoolId): bool
    {
        return $this->school_id === $schoolId;
    }

    /**
     * Get user statistics for dashboard
     */
    public function getStatsAttribute(): array
    {
        $stats = [
            'total_logins' => $this->loginHistory()->count(),
            'last_activity' => $this->last_login_at,
            'account_age_days' => $this->created_at->diffInDays(now()),
            'password_age_days' => $this->password_changed_at ? 
                Carbon::parse($this->password_changed_at)->diffInDays(now()) : null,
            'failed_attempts' => $this->failed_login_attempts,
            'is_locked' => $this->isLocked(),
            'needs_password_change' => $this->needsPasswordChange(),
            'two_factor_enabled' => $this->hasTwoFactorEnabled()
        ];

        return $stats;
    }

    /**
     * Search users by various criteria
     */
    public function scopeSearch($query, string $search)
    {
        return $query->where(function ($q) use ($search) {
            $q->where('name', 'like', "%{$search}%")
              ->orWhere('email', 'like', "%{$search}%")
              ->orWhere('username', 'like', "%{$search}%")
              ->orWhere('mobile_no', 'like', "%{$search}%");
        });
    }

    /**
     * Get users by date range
     */
    public function scopeCreatedBetween($query, $startDate, $endDate)
    {
        return $query->whereBetween('created_at', [$startDate, $endDate]);
    }

    /**
     * Get recently active users
     */
    public function scopeRecentlyActive($query, int $days = 30)
    {
        return $query->where('last_login_at', '>=', now()->subDays($days));
    }

    /**
     * Data Export Methods (for GDPR compliance)
     */

    /**
     * Export user data for GDPR compliance
     */
    public function exportPersonalData(): array
    {
        return [
            'personal_information' => [
                'name' => $this->name,
                'email' => $this->email,
                'username' => $this->username,
                'mobile_no' => $this->mobile_no,
                'school_id' => $this->school_id,
                'role' => $this->getRoleNames()->first()
            ],
            'account_information' => [
                'uuid' => $this->uuid,
                'created_at' => $this->created_at,
                'last_login_at' => $this->last_login_at,
                'last_login_ip' => $this->last_login_ip,
                'is_verified' => $this->is_verified,
                'is_active' => $this->is_active
            ],
            'activity_logs' => $this->activities()->get()->toArray(),
            'permissions' => $this->getPermissionsArray(),
            'roles' => $this->getRolesArray(),
            'export_date' => now()->toISOString()
        ];
    }

    /**
     * Anonymize user data (for GDPR right to be forgotten)
     */
    public function anonymizeData(): bool
    {
        try {
            $this->update([
                'name' => 'Anonymized User',
                'email' => 'anonymized_' . $this->id . '@deleted.local',
                'username' => 'anonymized_' . $this->id,
                'mobile_no' => null,
                'is_active' => false,
                'otp' => null,
                'two_factor_secret' => null,
                'two_factor_recovery_codes' => null
            ]);

            activity()
                ->performedOn($this)
                ->withProperties([
                    'anonymized_by' => auth()->id(),
                    'reason' => 'GDPR right to be forgotten'
                ])
                ->log('User data anonymized');

            return true;
        } catch (\Exception $e) {
            \Log::error('User anonymization failed: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Custom validation rules
     */
    public static function getValidationRules(bool $isUpdate = false, int $userId = null): array
    {
        $rules = [
            'name' => 'required|string|max:255|regex:/^[a-zA-Z\s]+$/',
            'email' => 'required|email|max:255|unique:users,email' . ($isUpdate ? ",$userId" : ''),
            'username' => 'required|string|max:50|unique:users,username' . ($isUpdate ? ",$userId" : ''),
            'mobile_no' => 'nullable|string|max:15|regex:/^\+?[1-9]\d{1,14}$/',
            'roles' => 'required|array|min:1', 'roles.*' => 'exists:roles,name',
            'school_id' => 'nullable|string|max:50|alpha_num',
        ];

        if (!$isUpdate) {
            $rules['password'] = [
                'required',
                'string',
                'min:8',
                'regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]/',
                'confirmed'
            ];
        }

        return $rules;
    }
}