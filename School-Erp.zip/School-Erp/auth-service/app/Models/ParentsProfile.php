<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ParentsProfile extends Model
{
    use HasFactory;

    protected $table = 'parents_profiles';

    protected $fillable = [
        'user_id',      // reference to users table
        'father_name',
        'mother_name',
        'primary_mobile',
        'secondary_mobile',
        'email',
        'address',
        'city',
        'state',
        'pincode',
        'occupation',
        'annual_income',
    ];

    /**
     * Each parent has one user account
     */
    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    /**
     * A parent can have many students
     */
    public function students()
    {
        return $this->hasMany(Student::class, 'parent_id');
    }
}
