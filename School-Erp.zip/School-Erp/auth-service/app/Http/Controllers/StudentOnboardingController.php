<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Student;
use App\Models\ParentsProfile;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Log;

class StudentOnboardingController extends Controller
{
    // Remove constructor - middleware is already applied in routes
    // The route already has: Route::middleware(['jwt.auth', 'school.admin'])

    public function onboard(Request $request)
    {
        $admin = auth()->user(); // JWT-authenticated admin
        $schoolId = $admin->school_id;

        // -----------------------------
        // Validation
        // -----------------------------
        $request->validate([
            'student_name' => 'required|string|max:255',
            'gender' => 'required|in:male,female,other',
            'date_of_birth' => 'required|date',
            'admission_number' => 'required|string|unique:students,admission_number',
            'class' => 'required|string',
            'section' => 'required|string',
            'parent_option' => 'required|in:existing,new',
            'existing_parent_student_id' => 'nullable|exists:students,id',

            // New parent fields
            'father_name' => 'required_if:parent_option,new|string|max:255',
            'mother_name' => 'nullable|string|max:255',
            'parent_primary_mobile' => 'required_if:parent_option,new|string|max:15|unique:parents_profiles,primary_mobile',
            'parent_email' => 'nullable|email|unique:users,email',

            // Document uploads
            'photo' => 'nullable|image|max:2048',
            'birth_certificate' => 'nullable|file|mimes:pdf,jpg,jpeg,png|max:4096',
            'aadhar_card' => 'nullable|file|mimes:pdf,jpg,jpeg,png|max:4096',
            'transfer_certificate' => 'nullable|file|mimes:pdf,jpg,jpeg,png|max:4096',
        ]);

        DB::beginTransaction();

        try {
            // -----------------------------
            // Step 1: Parent Handling
            // -----------------------------
            $parentId = null;

            if ($request->parent_option === 'existing') {
                $existingStudent = Student::findOrFail($request->existing_parent_student_id);
                $parentId = $existingStudent->parent_id;
                $parent_email = $existingStudent->parent ? $existingStudent->parent->email : null;
                Log::info('Parent option:', ['value' => $request->parent_option]);
                Log::info('Existing student:', $existingStudent->toArray());
                Log::info('Parent ID:', ['parent_id' => $parentId]);
                Log::info('parent_email:', ['parent_email' => $parent_email]);
                if (!$parentId) {
                    return response()->json(['error' => 'Parent not found for selected student'], 404);
                }
            } else {
                // Create Parent User
                $parentUser = User::create([
                    'name' => $request->father_name,
                    'username' => Str::slug($request->father_name) . rand(1000, 9999),
                    'email' => $request->parent_email,
                    'password' => Hash::make('School@123'), // default password
                    'school_id' => $schoolId,
                    'role' => 'parent',
                     'is_verified' => true,
                     'is_active' => true,
                     'email_verified_at' => now(),
                ]);
                $parentUser->assignRole('parent');

                // Create Parent Profile
                $parent = ParentsProfile::create([
                    'user_id' => $parentUser->id,
                    'father_name' => $request->father_name,
                    'mother_name' => $request->mother_name,
                    'primary_mobile' => $request->parent_primary_mobile,
                    'email' => $request->parent_email,
                ]);

                $parentId = $parent->id;
            }

            // -----------------------------
            // Step 2: Student User
            // -----------------------------
           if ($request->parent_option === 'new') {
    $email = $request->parent_email;
    Log::info('Parent Option is new', ['email' => $email]);
} else {
    $email = $parent_email;
    Log::info('Parent Option is Existing', ['email' => $email]);
}

            $studentUser = User::create([
                'name' => $request->student_name,
                'email' => $email,
                'username' => Str::slug($request->student_name) . rand(1000, 9999),
                'password' => Hash::make('School@123'),
                'school_id' => $schoolId,
                'is_verified' => true,
                'is_active' => true,
                'email_verified_at' => now(),
            ]);
            $studentUser->assignRole('student');

            // -----------------------------
            // Step 3: Upload Documents
            // -----------------------------
            $documentFields = ['photo', 'birth_certificate', 'aadhar_card', 'transfer_certificate'];
            $uploaded = [];

            foreach ($documentFields as $field) {
                if ($request->hasFile($field)) {
                    $uploaded[$field] = $request->file($field)->store('students/' . $field, 'public');
                }
            }

            // -----------------------------
            // Step 4: Create Student Profile
            // -----------------------------
            $student = Student::create(array_merge([
                'user_id' => $studentUser->id,
                'parent_id' => $parentId,
                'full_name' => $request->student_name,
                'gender' => $request->gender,
                'date_of_birth' => $request->date_of_birth,
                'admission_number' => $request->admission_number,
                'class' => $request->class,
                'section' => $request->section,
                'status' => 1,
            ], $uploaded));

            DB::commit();

            return response()->json([
                'message' => 'Student onboarded successfully',
                'student_id' => $student->id,
                'parent_id' => $parentId
            ], 201);

        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'error' => 'Student onboarding failed',
                'message' => $e->getMessage()
            ], 500);
        }
    }
}