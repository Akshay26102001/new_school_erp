<?php

namespace App\Http\Controllers;

use Illuminate\Routing\Controller;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Validation\ValidatesRequests;

use App\Models\School;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;

class SchoolController extends Controller
{
    use AuthorizesRequests, ValidatesRequests;

    // Authentication is handled by jwt.auth middleware in routes
    // No constructor needed

    /**
     * List all schools (Super Admin only)
     */
    public function index(Request $request): JsonResponse
    {
        try {
            $this->authorize('viewAny', School::class);

            $query = School::query();

            if ($request->has('search')) {
                $search = $request->search;
                $query->where(function ($q) use ($search) {
                    $q->where('name', 'like', "%{$search}%")
                      ->orWhere('school_code', 'like', "%{$search}%")
                      ->orWhere('display_name', 'like', "%{$search}%")
                      ->orWhere('city', 'like', "%{$search}%");
                });
            }

            if ($request->has('status')) {
                $query->where('status', $request->status);
            }

            if ($request->has('school_type')) {
                $query->where('school_type', $request->school_type);
            }

            $perPage = min($request->get('per_page', 15), 100);
            $schools = $query->orderBy('created_at', 'desc')->paginate($perPage);

            return $this->successResponse('Schools retrieved successfully', $schools);

        } catch (\Exception $e) {
            \Log::error('School index error: ' . $e->getMessage());
            return $this->errorResponse('Failed to retrieve schools');
        }
    }

    /**
     * Onboard a new school (Super Admin only)
     */
    public function store(Request $request): JsonResponse
    {
        try {
            $this->authorize('create', School::class);

            $validator = Validator::make($request->all(), [
                'name' => 'required|string|max:255|regex:/^[a-zA-Z0-9\s\-\.]+$/|unique:schools,name',
                'display_name' => 'nullable|string|max:255',
                'school_type' => 'required|in:public,private,charter,international,boarding',
                'education_level' => 'required|in:elementary,middle,high,k12,preschool',
                'registration_number' => 'nullable|string|max:100|unique:schools,registration_number',
                'email' => 'required|email:rfc,dns|unique:schools,email',
                'phone' => 'required|string|max:20|regex:/^[+]?[0-9\s\-\(\)]+$/',
                'address_line_1' => 'required|string|max:255',
                'address_line_2' => 'nullable|string|max:255',
                'city' => 'required|string|max:100',
                'state' => 'required|string|max:100',
                'postal_code' => 'required|string|max:20|regex:/^[A-Z0-9\s\-]+$/i',
                'country' => 'required|string|max:100',
                'principal_name' => 'required|string|max:255',
                'principal_email' => 'required|email:rfc,dns|different:email',
                'principal_phone' => 'required|string|max:20|regex:/^[+]?[0-9\s\-\(\)]+$/',
                'website' => 'nullable|url',
                'founded_date' => 'nullable|date|before:today',
                'description' => 'nullable|string|max:1000',
                'board_affiliation' => 'nullable|string|max:100',
                'medium_of_instruction' => 'nullable|string|max:100',
            ]);

            if ($validator->fails()) {
                return $this->errorResponse('Validation failed', 422, $validator->errors());
            }

            DB::beginTransaction();
            try {
                $school = School::create([
                    'name' => $request->name,
                    'display_name' => $request->display_name ?? $request->name,
                    'school_code' => $this->generateUniqueSchoolCode($request->name),
                    'registration_number' => $request->registration_number,
                    'school_type' => $request->school_type,
                    'education_level' => $request->education_level,
                    'founded_date' => $request->founded_date,
                    'description' => $request->description,
                    'status' => 'pending',
                    'address_line_1' => $request->address_line_1,
                    'address_line_2' => $request->address_line_2,
                    'city' => $request->city,
                    'state' => $request->state,
                    'postal_code' => $request->postal_code,
                    'country' => $request->country,
                    'phone' => $request->phone,
                    'email' => $request->email,
                    'website' => $request->website,
                    'principal_name' => $request->principal_name,
                    'principal_email' => $request->principal_email,
                    'principal_phone' => $request->principal_phone,
                    'board_affiliation' => $request->board_affiliation,
                    'medium_of_instruction' => $request->medium_of_instruction,
                    'created_by' => $request->user()->id,
                    'is_verified' => false
                ]);

                DB::commit();

                return $this->successResponse('School onboarded successfully', $school, 201);

            } catch (\Exception $e) {
                DB::rollback();
                throw $e;
            }

        } catch (\Exception $e) {
            \Log::error('School onboarding error: ' . $e->getMessage());
            return $this->errorResponse('School onboarding failed');
        }
    }

    /**
     * View a school
     */
    public function show(Request $request, School $school): JsonResponse
    {
        try {
            $this->authorize('view', $school);

            return $this->successResponse('School retrieved successfully', $school);

        } catch (\Exception $e) {
            \Log::error('School show error: ' . $e->getMessage());
            return $this->errorResponse('Failed to retrieve school');
        }
    }

    /**
     * Update school information
     */
    public function update(Request $request, School $school): JsonResponse
    {
        try {
            $this->authorize('update', $school);

            $validator = Validator::make($request->all(), [
                'name' => 'sometimes|string|max:255|regex:/^[a-zA-Z0-9\s\-\.]+$/|unique:schools,name,' . $school->id,
                'display_name' => 'nullable|string|max:255',
                'email' => 'sometimes|email:rfc,dns|unique:schools,email,' . $school->id,
                'phone' => 'sometimes|string|max:20|regex:/^[+]?[0-9\s\-\(\)]+$/',
                'address_line_1' => 'sometimes|string|max:255',
                'address_line_2' => 'nullable|string|max:255',
                'city' => 'sometimes|string|max:100',
                'state' => 'sometimes|string|max:100',
                'postal_code' => 'sometimes|string|max:20|regex:/^[A-Z0-9\s\-]+$/i',
                'country' => 'sometimes|string|max:100',
                'website' => 'nullable|url',
                'description' => 'nullable|string|max:1000',
                'principal_name' => 'sometimes|string|max:255',
                'principal_email' => 'sometimes|email:rfc,dns',
                'principal_phone' => 'sometimes|string|max:20|regex:/^[+]?[0-9\s\-\(\)]+$/',
                'board_affiliation' => 'nullable|string|max:100',
                'medium_of_instruction' => 'nullable|string|max:100',
            ]);

            if ($validator->fails()) {
                return $this->errorResponse('Validation failed', 422, $validator->errors());
            }

            $school->update(array_merge(
                $request->only([
                    'name', 'display_name', 'email', 'phone', 'address_line_1', 'address_line_2',
                    'city', 'state', 'postal_code', 'country', 'website', 'description',
                    'principal_name', 'principal_email', 'principal_phone', 
                    'board_affiliation', 'medium_of_instruction'
                ]),
                ['updated_by' => $request->user()->id]
            ));

            return $this->successResponse('School updated successfully', $school);

        } catch (\Exception $e) {
            \Log::error('School update error: ' . $e->getMessage());
            return $this->errorResponse('Failed to update school');
        }
    }

    /**
     * Activate / Approve a school (Super Admin only)
     */
    public function activate(Request $request, School $school): JsonResponse
    {
        try {
            $this->authorize('activate', $school);

            $school->update([
                'status' => 'active',
                'is_verified' => true,
                'verification_date' => now(),
                'updated_by' => $request->user()->id
            ]);

            return $this->successResponse('School activated successfully');

        } catch (\Exception $e) {
            \Log::error('School activation error: ' . $e->getMessage());
            return $this->errorResponse('Failed to activate school');
        }
    }

    /**
     * Deactivate a school (Super Admin only)
     */
    public function deactivate(Request $request, School $school): JsonResponse
    {
        try {
            $this->authorize('deactivate', $school);

            $school->update([
                'status' => 'inactive',
                'updated_by' => $request->user()->id
            ]);

            return $this->successResponse('School deactivated successfully');

        } catch (\Exception $e) {
            \Log::error('School deactivation error: ' . $e->getMessage());
            return $this->errorResponse('Failed to deactivate school');
        }
    }

    /**
     * Success response helper
     */
    private function successResponse($message, $data = null, $code = 200): JsonResponse
    {
        $response = [
            'status' => 'success',
            'message' => $message
        ];

        if ($data !== null) {
            $response['data'] = $data;
        }

        return response()->json($response, $code);
    }

    /**
     * Error response helper
     */
    private function errorResponse($message, $code = 500, $errors = null): JsonResponse
    {
        $response = [
            'status' => 'error',
            'message' => $message
        ];

        if ($errors) {
            $response['errors'] = $errors;
        }

        return response()->json($response, $code);
    }

    /**
     * Generate unique school code
     */
    private function generateUniqueSchoolCode(string $schoolName): string
    {
        $prefix = 'SCH';
        $year = date('Y');
        $nameCode = strtoupper(substr(preg_replace('/[^A-Za-z]/', '', $schoolName), 0, 3));
        $nameCode = str_pad($nameCode, 3, '0');

        $counter = 1;
        $maxAttempts = 9999;

        do {
            $code = $prefix . $year . $nameCode . str_pad($counter, 4, '0', STR_PAD_LEFT);
            $exists = School::where('school_code', $code)->exists();
            $counter++;
        } while ($exists && $counter <= $maxAttempts);

        if ($counter > $maxAttempts) {
            throw new \Exception('Unable to generate unique school code');
        }

        return $code;
    }
}