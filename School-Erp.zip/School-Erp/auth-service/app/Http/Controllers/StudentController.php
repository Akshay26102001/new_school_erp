<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class StudentController extends Controller
{
  public function index()
{
    return response()->json([
        'message' => 'Welcome Student',
        'assignments_due' => 3,
        'attendance' => '92%',
    ]);
}
}
