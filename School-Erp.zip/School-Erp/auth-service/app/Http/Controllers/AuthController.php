<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use App\Models\User;
use Tymon\JWTAuth\Facades\JWTAuth;
use Tymon\JWTAuth\Exceptions\JWTException;
use App\Mail\VerifyOtpMail;
use App\Mail\WelcomeMail;
use Carbon\Carbon;
use App\Mail\PasswordResetOtpMail;

class AuthController extends Controller
{
    /**
     * Maximum login attempts before lockout
     */
    const MAX_LOGIN_ATTEMPTS = 5;
    const LOCKOUT_DURATION = 900; // 15 minutes in seconds
    const OTP_EXPIRY_MINUTES = 10;

    /**
     * Register a new user - NO JWT TOKENS GENERATED
     * User must verify email before being able to login
     */
    public function register(Request $request): JsonResponse
    {
        try {
            // Enhanced validation with security rules
            $validator = Validator::make($request->all(), [
                'name' => [
                    'required',
                    'string',
                    'max:255',
                    'regex:/^[a-zA-Z\s]+$/', // Only letters and spaces
                ],
                'email' => [
                    'required',
                    'email',
                    'max:255',
                    'unique:users,email',
                    'regex:/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/'
                ],
                'password' => [
                    'required',
                    'string',
                    'min:8',
                    'regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]/',
                    'confirmed'
                ],
                'password_confirmation' => 'required|string',
                'role' => 'required|in:student,teacher,admin,staff',
                'mobile_no' => [
                    'nullable',
                    'string',
                    'max:15',
                    'regex:/^\+?[1-9]\d{1,14}$/'
                ],
                'school_id' => 'nullable|string|max:50|alpha_num',
            ], [
                'password.regex' => 'Password must contain at least one uppercase letter, one lowercase letter, one number and one special character',
                'name.regex' => 'Name should only contain letters and spaces',
                'email.regex' => 'Please provide a valid email address',
                'mobile_no.regex' => 'Please provide a valid phone number'
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'status' => 'error',
                    'message' => 'Validation failed',
                    'errors' => $validator->errors()
                ], 422);
            }

            $validated = $validator->validated();
            $ipAddress = $request->ip();

            // Rate limiting for registration
            $rateLimitKey = 'register:' . $ipAddress;
            if (RateLimiter::tooManyAttempts($rateLimitKey, 3)) { // 3 registrations per hour
                $seconds = RateLimiter::availableIn($rateLimitKey);
                
                $this->logSecurityEvent('registration_rate_limit_exceeded', [
                    'ip_address' => $ipAddress,
                    'email' => $validated['email']
                ]);

                return response()->json([
                    'status' => 'error',
                    'message' => 'Too many registration attempts. Please try again later.',
                    'retry_after' => $seconds
                ], 429);
            }

            DB::beginTransaction();

            try {
                // Generate unique username
                $baseUsername = Str::slug($validated['name']);
                $username = $this->generateUniqueUsername($baseUsername);

                // Create user with UNVERIFIED status - NO PERMISSIONS YET
                $user = User::create([
                    'uuid' => Str::uuid(),
                    'username' => $username,
                    'name' => $validated['name'],
                    'email' => $validated['email'],
                    'password' => Hash::make($validated['password']),
                    'role' => $validated['role'], // Store role but don't assign permissions yet
                    'mobile_no' => $validated['mobile_no'] ?? null,
                    'school_id' => $validated['school_id'] ?? null,
                    'is_verified' => false, // CRITICAL: User is not verified
                    'is_active' => false, // CRITICAL: User cannot login until verified
                    'password_changed_at' => now(),
                    'must_change_password' => false,
                    'failed_login_attempts' => 0,
                ]);

                // Generate secure verification token (NOT JWT)
                $verificationToken = $this->generateSecureVerificationToken();
                
                // Generate OTP for email verification
                $otp = $this->generateSecureOTP();
                $user->update([
                    'otp' => Hash::make($otp), // Hash the OTP for security
                    'otp_expires_at' => now()->addMinutes(self::OTP_EXPIRY_MINUTES),
                    'email_verification_token' => Hash::make($verificationToken) // Additional security layer
                ]);

                // Send verification email with OTP
                try {
                    Mail::to($user->email)->send(new VerifyOtpMail($otp, $user->name));
                    
                    $this->logSecurityEvent('registration_successful', [
                        'user_id' => $user->id,
                        'email' => $user->email,
                        'role' => $user->role,
                        'ip_address' => $ipAddress,
                        'verification_required' => true
                    ]);

                } catch (\Exception $e) {
                    \Log::error('OTP email failed: ' . $e->getMessage(), [
                        'user_id' => $user->id,
                        'email' => $user->email
                    ]);
                    
                    // Don't fail registration if email fails
                }

                DB::commit();

                // Hit rate limiter
                RateLimiter::hit($rateLimitKey, 3600); // 1 hour

                return response()->json([
                    'status' => 'success',
                    'message' => 'Registration successful. Please check your email and verify your account with the OTP before you can login.',
                    'data' => [
                        'user_id' => $user->id,
                        'email' => $user->email,
                        'verification_required' => true,
                        'otp_expires_in' => self::OTP_EXPIRY_MINUTES * 60, // in seconds
                        'next_step' => 'Please check your email for OTP and call /api/auth/verify-otp endpoint'
                    ]
                ], 201);

            } catch (\Exception $e) {
                DB::rollback();
                throw $e;
            }

        } catch (\Exception $e) {
            \Log::error('Registration error: ' . $e->getMessage(), [
                'ip_address' => $request->ip(),
                'email' => $request->email ?? 'unknown'
            ]);

            return response()->json([
                'status' => 'error',
                'message' => 'Registration failed. Please try again.'
            ], 500);
        }
    }

    /**
     * Verify OTP for email verification - ACTIVATES USER ACCOUNT
     * This is when user gets activated and can login
     */
    public function verifyOtp(Request $request): JsonResponse
    {
        try {
            $validator = Validator::make($request->all(), [
                'user_id' => 'required|integer|exists:users,id',
                'otp' => 'required|string|size:6|regex:/^[0-9]{6}$/'
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'status' => 'error',
                    'message' => 'Invalid input',
                    'errors' => $validator->errors()
                ], 422);
            }

            $user = User::find($request->user_id);

            // Security checks
            if (!$user) {
                return response()->json([
                    'status' => 'error',
                    'message' => 'User not found'
                ], 400);
            }

            if ($user->is_verified) {
                return response()->json([
                    'status' => 'error',
                    'message' => 'User already verified. You can login now.'
                ], 400);
            }

            // Check OTP expiry
            if (!$user->otp_expires_at || Carbon::parse($user->otp_expires_at)->isPast()) {
                return response()->json([
                    'status' => 'error',
                    'message' => 'OTP has expired. Please request a new one.',
                    'action' => 'Call /api/auth/resend-otp endpoint'
                ], 400);
            }

            // Verify OTP
            if (!Hash::check($request->otp, $user->otp)) {
                // Increment failed attempts
                $user->increment('failed_login_attempts');
                
                $this->logSecurityEvent('otp_verification_failed', [
                    'user_id' => $user->id,
                    'ip_address' => $request->ip(),
                    'failed_attempts' => $user->failed_login_attempts + 1
                ]);

                // Lock account after too many failed OTP attempts
                if ($user->failed_login_attempts >= 5) {
                    $user->update(['locked_until' => now()->addMinutes(15)]);
                    
                    return response()->json([
                        'status' => 'error',
                        'message' => 'Account temporarily locked due to too many failed OTP attempts.'
                    ], 423);
                }

                return response()->json([
                    'status' => 'error',
                    'message' => 'Invalid OTP',
                    'remaining_attempts' => 5 - $user->failed_login_attempts
                ], 400);
            }

            // SUCCESS: Activate user account and assign permissions
            DB::beginTransaction();
            try {
                $user->update([
                    'is_verified' => true,
                    'is_active' => true, // NOW user can login
                    'email_verified_at' => now(),
                    'otp' => null,
                    'otp_expires_at' => null,
                    'email_verification_token' => null,
                    'failed_login_attempts' => 0,
                    'locked_until' => null
                ]);

                // NOW assign the role and permissions after verification
                $user->assignRole($user->role);

                $this->logSecurityEvent('email_verified_account_activated', [
                    'user_id' => $user->id,
                    'ip_address' => $request->ip(),
                    'role_assigned' => $user->role
                ]);

                DB::commit();

                // Send welcome email
                try {
                    Mail::to($user->email)->send(new WelcomeMail($user));
                } catch (\Exception $e) {
                    \Log::error('Welcome email failed: ' . $e->getMessage());
                }

                return response()->json([
                    'status' => 'success',
                    'message' => 'Email verified successfully! Your account is now active and you can login.',
                    'data' => [
                        'user_id' => $user->id,
                        'account_active' => true,
                        'can_login' => true,
                        'next_step' => 'You can now login using /api/auth/login endpoint'
                    ]
                ], 200);

            } catch (\Exception $e) {
                DB::rollback();
                throw $e;
            }

        } catch (\Exception $e) {
            \Log::error('OTP verification error: ' . $e->getMessage());
            
            return response()->json([
                'status' => 'error',
                'message' => 'Verification failed. Please try again.'
            ], 500);
        }
    }

    /**
     * Resend OTP for verification
     */
    public function resendOtp(Request $request): JsonResponse
    {
        try {
            $validator = Validator::make($request->all(), [
                'user_id' => 'required|integer|exists:users,id'
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'status' => 'error',
                    'errors' => $validator->errors()
                ], 422);
            }

            $user = User::find($request->user_id);

            if (!$user) {
                return response()->json([
                    'status' => 'error',
                    'message' => 'User not found'
                ], 400);
            }

            if ($user->is_verified) {
                return response()->json([
                    'status' => 'error',
                    'message' => 'User already verified. You can login now.'
                ], 400);
            }

            // Rate limiting
            $rateLimitKey = 'resend_otp:' . $user->id;
            if (RateLimiter::tooManyAttempts($rateLimitKey, 3)) { // 3 attempts per hour
                return response()->json([
                    'status' => 'error',
                    'message' => 'Too many OTP requests. Please wait before requesting again.'
                ], 429);
            }

            // Generate new OTP
            $otp = $this->generateSecureOTP();
            $user->update([
                'otp' => Hash::make($otp),
                'otp_expires_at' => now()->addMinutes(self::OTP_EXPIRY_MINUTES)
            ]);

            // Send OTP
            Mail::to($user->email)->send(new VerifyOtpMail($otp, $user->name));

            RateLimiter::hit($rateLimitKey, 3600);

            $this->logSecurityEvent('otp_resent', [
                'user_id' => $user->id,
                'ip_address' => $request->ip()
            ]);

            return response()->json([
                'status' => 'success',
                'message' => 'New OTP sent to your email',
                'data' => [
                    'otp_expires_in' => self::OTP_EXPIRY_MINUTES * 60
                ]
            ], 200);

        } catch (\Exception $e) {
            \Log::error('Resend OTP error: ' . $e->getMessage());
            
            return response()->json([
                'status' => 'error',
                'message' => 'Failed to resend OTP'
            ], 500);
        }
    }

    /**
     * LOGIN - Only verified users can get JWT tokens
     * This is where JWT tokens are generated for the first time
     */
    public function loginBackup(Request $request): JsonResponse
    {
        try {
            $validator = Validator::make($request->all(), [
                'email' => 'required|email|max:255',
                'password' => 'required|string|min:6'
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'status' => 'error',
                    'message' => 'Invalid input',
                    'errors' => $validator->errors()
                ], 422);
            }

            $credentials = $request->only('email', 'password');
            $ipAddress = $request->ip();
            $userAgent = $request->userAgent();

            // Rate limiting
            $rateLimitKey = 'login:' . $ipAddress;
            if (RateLimiter::tooManyAttempts($rateLimitKey, self::MAX_LOGIN_ATTEMPTS)) {
                $seconds = RateLimiter::availableIn($rateLimitKey);
                
                $this->logSecurityEvent('login_rate_limit_exceeded', [
                    'ip_address' => $ipAddress,
                    'email' => $credentials['email']
                ]);

                return response()->json([
                    'status' => 'error',
                    'message' => 'Too many login attempts. Please try again in ' . ceil($seconds / 60) . ' minutes.',
                    'retry_after' => $seconds
                ], 429);
            }

            // Find user first for pre-authentication checks
            $user = User::where('email', $credentials['email'])->first();

            // Pre-authentication security checks
            if ($user) {
                // Check if user is verified
                if (!$user->is_verified) {
                    $this->logSecurityEvent('unverified_login_attempt', [
                        'user_id' => $user->id,
                        'ip_address' => $ipAddress
                    ]);

                    return response()->json([
                        'status' => 'error',
                        'message' => 'Please verify your email before logging in',
                        'data' => [
                            'user_id' => $user->id,
                            'verification_required' => true,
                            'action' => 'Call /api/auth/verify-otp or /api/auth/resend-otp'
                        ]
                    ], 403);
                }

                // Check if user is active
                if (!$user->is_active) {
                    $this->logSecurityEvent('inactive_user_login_attempt', [
                        'user_id' => $user->id,
                        'ip_address' => $ipAddress
                    ]);

                    return response()->json([
                        'status' => 'error',
                        'message' => 'Account is deactivated. Contact administrator.'
                    ], 403);
                }

                // Check account lockout
                if ($user->locked_until && Carbon::parse($user->locked_until)->isFuture()) {
                    $this->logSecurityEvent('locked_account_login_attempt', [
                        'user_id' => $user->id,
                        'ip_address' => $ipAddress
                    ]);

                    return response()->json([
                        'status' => 'error',
                        'message' => 'Account is temporarily locked. Please try again later.'
                    ], 423);
                }
            }

            // Attempt JWT authentication - ONLY for verified, active users
            if (!$token = JWTAuth::attempt($credentials)) {
                // Log failed attempt
                if ($user) {
                    $user->increment('failed_login_attempts');
                    
                    // Lock account after 5 failed attempts
                    if ($user->failed_login_attempts >= 5) {
                        $user->update([
                            'locked_until' => now()->addMinutes(15)
                        ]);
                        
                        $this->logSecurityEvent('account_locked_failed_attempts', [
                            'user_id' => $user->id,
                            'ip_address' => $ipAddress
                        ]);
                    }
                }

                RateLimiter::hit($rateLimitKey, self::LOCKOUT_DURATION);

                $this->logSecurityEvent('login_failed', [
                    'email' => $credentials['email'],
                    'ip_address' => $ipAddress,
                    'user_agent' => $userAgent
                ]);

                return response()->json([
                    'status' => 'error',
                    'message' => 'Invalid credentials'
                ], 401);
            }

            $user = JWTAuth::setToken($token)->toUser();

            // Additional post-authentication checks
            if ($user->must_change_password) {
                // Don't invalidate token, but inform about password change
                return response()->json([
                    'status' => 'password_change_required',
                    'message' => 'Password change required before full access',
                    'data' => [
                        'token' => $token,
                        'temp_access' => true,
                        'action' => 'Call /api/auth/change-password'
                    ]
                ], 200);
            }

            // SUCCESS: Clear rate limiting and update login info
            RateLimiter::clear($rateLimitKey);

            $user->update([
                'last_login_at' => now(),
                'last_login_ip' => $ipAddress,
                'failed_login_attempts' => 0,
                'locked_until' => null
            ]);

            $this->logSecurityEvent('login_successful', [
                'user_id' => $user->id,
                'ip_address' => $ipAddress,
                'user_agent' => $userAgent,
                'jwt_generated' => true
            ]);

            return response()->json([
                'status' => 'success',
                'message' => 'Login successful',
                'data' => [
                    'token' => $token,
                    'token_type' => 'bearer',
                    'expires_in' => JWTAuth::factory()->getTTL() * 60, // in seconds
                    'user' => [
                        'id' => $user->id,
                        'uuid' => $user->uuid,
                        'name' => $user->name,
                        'email' => $user->email,
                        'username' => $user->username,
                        'role' => $user->role,
                        'school_id' => $user->school_id,
                        'permissions' => $user->getAllPermissions()->pluck('name'),
                        'last_login' => $user->last_login_at,
                        'is_verified' => $user->is_verified
                    ]
                ]
            ], 200);

        } catch (JWTException $e) {
            \Log::error('JWT Exception during login: ' . $e->getMessage());
            
            return response()->json([
                'status' => 'error',
                'message' => 'Authentication failed'
            ], 500);

        } catch (\Exception $e) {
            \Log::error('Login error: ' . $e->getMessage(), [
                'ip_address' => $request->ip(),
                'email' => $request->email ?? 'unknown'
            ]);

            return response()->json([
                'status' => 'error',
                'message' => 'Login failed. Please try again.'
            ], 500);
        }
    }

    // New Methods for login

    public function login(Request $request): JsonResponse
 {
     try {
         $validator = Validator::make($request->all(), [
             'login' => 'required|string|max:255', // Can be email or username
             'password' => 'required|string|min:6'
         ]);
         if ($validator->fails()) {
             return response()->json([
                 'status' => 'error',
                 'message' => 'Invalid input',
                 'errors' => $validator->errors()
             ], 422);
         }
         $loginInput = $request->input('login');
         $field = filter_var($loginInput, FILTER_VALIDATE_EMAIL) ? 'email' : 'username';
         $credentials = [
             $field => $loginInput,
             'password' => $request->input('password')
         ];
         $ipAddress = $request->ip();
         $userAgent = $request->userAgent();
         $rateLimitKey = 'login:' . $ipAddress;
         if (RateLimiter::tooManyAttempts($rateLimitKey, self::MAX_LOGIN_ATTEMPTS)) {
             $seconds = RateLimiter::availableIn($rateLimitKey);
             $this->logSecurityEvent('login_rate_limit_exceeded', [
                 'ip_address' => $ipAddress,
                 'login_input' => $loginInput
             ]);
             return response()->json([
                 'status' => 'error',
                 'message' => 'Too many login attempts. Please try again in ' . ceil($seconds / 60) . ' minutes.',
                 'retry_after' => $seconds
             ], 429);
         }
         $user = User::where($field, $loginInput)->first();
         if ($user) {
             // Check verification
             if (!$user->is_verified) {
                 $this->logSecurityEvent('unverified_login_attempt', [
                     'user_id' => $user->id,
                     'ip_address' => $ipAddress
                 ]);
                 return response()->json([
                     'status' => 'error',
                     'message' => 'Please verify your email before logging in',
                     'data' => [
                         'user_id' => $user->id,
                         'verification_required' => true,
                         'action' => 'Call /api/auth/verify-otp or /api/auth/resend-otp'
                     ]
                 ], 403);
             }
             if (!$user->is_active) {
                 $this->logSecurityEvent('inactive_user_login_attempt', [
                     'user_id' => $user->id,
                     'ip_address' => $ipAddress
                 ]);
                 return response()->json([
                     'status' => 'error',
                     'message' => 'Account is deactivated. Contact administrator.'
                 ], 403);
             }
             if ($user->locked_until && Carbon::parse($user->locked_until)->isFuture()) {
                 $this->logSecurityEvent('locked_account_login_attempt', [
                     'user_id' => $user->id,
                     'ip_address' => $ipAddress
                 ]);
                 return response()->json([
                     'status' => 'error',
                     'message' => 'Account is temporarily locked. Please try again later.'
                 ], 423);
             }
         }
         if (!$token = JWTAuth::attempt($credentials)) {
             if ($user) {
                 $user->increment('failed_login_attempts');
                 if ($user->failed_login_attempts >= 5) {
                     $user->update(['locked_until' => now()->addMinutes(15)]);
                     $this->logSecurityEvent('account_locked_failed_attempts', [
                         'user_id' => $user->id,
                         'ip_address' => $ipAddress
                     ]);
                 }
             }
             RateLimiter::hit($rateLimitKey, self::LOCKOUT_DURATION);
             $this->logSecurityEvent('login_failed', [
                 'login_input' => $loginInput,
                 'ip_address' => $ipAddress,
                 'user_agent' => $userAgent
             ]);
             return response()->json([
                 'status' => 'error',
                 'message' => 'Invalid credentials'
             ], 401);
         }
         $user = JWTAuth::setToken($token)->toUser();
         if ($user->must_change_password) {
             return response()->json([
                 'status' => 'password_change_required',
                 'message' => 'Password change required before full access',
                 'data' => [
                     'token' => $token,
                     'temp_access' => true,
                     'action' => 'Call /api/auth/change-password'
                 ]
             ], 200);
         }
         RateLimiter::clear($rateLimitKey);
         $user->update([
             'last_login_at' => now(),
             'last_login_ip' => $ipAddress,
             'failed_login_attempts' => 0,
             'locked_until' => null
         ]);
         $this->logSecurityEvent('login_successful', [
             'user_id' => $user->id,
             'ip_address' => $ipAddress,
             'user_agent' => $userAgent,
             'jwt_generated' => true
         ]);
         return response()->json([
             'status' => 'success',
             'message' => 'Login successful',
             'data' => [
                 'token' => $token,
                 'token_type' => 'bearer',
                 'expires_in' => JWTAuth::factory()->getTTL() * 60,
                 'user' => [
                     'id' => $user->id,
                     'uuid' => $user->uuid,
                     'name' => $user->name,
                     'email' => $user->email,
                     'username' => $user->username,
                     'role' => $user->role,
                     'school_id' => $user->school_id,
                     'permissions' => $user->getAllPermissions()->pluck('name'),
                     'last_login' => $user->last_login_at,
                     'is_verified' => $user->is_verified
                 ]
             ]
         ], 200);
     } catch (JWTException $e) {
         \Log::error('JWT Exception during login: ' . $e->getMessage());
         return response()->json([
             'status' => 'error',
             'message' => 'Authentication failed'
         ], 500);
     } catch (\Exception $e) {
         \Log::error('Login error: ' . $e->getMessage(), [
             'ip_address' => $request->ip(),
             'login_input' => $request->input('login') ?? 'unknown'
         ]);
         return response()->json([
             'status' => 'error',
             'message' => 'Login failed. Please try again.'
         ], 500);
     }
 }



    /**
     * Logout and invalidate JWT token
     */
    public function logout(Request $request): JsonResponse
    {
        try {
            $user = JWTAuth::parseToken()->authenticate();
            
            if ($user) {
                $this->logSecurityEvent('logout', [
                    'user_id' => $user->id,
                    'ip_address' => $request->ip()
                ]);
            }

            JWTAuth::invalidate(JWTAuth::getToken());

            return response()->json([
                'status' => 'success',
                'message' => 'Successfully logged out'
            ], 200);

        } catch (JWTException $e) {
            return response()->json([
                'status' => 'error',
                'message' => 'Failed to logout'
            ], 500);
        }
    }

    /**
     * Refresh JWT token
     */
    public function refresh(): JsonResponse
    {
        try {
            $token = JWTAuth::refresh(JWTAuth::getToken());
            
            $user = JWTAuth::setToken($token)->toUser();
            
            $this->logSecurityEvent('token_refreshed', [
                'user_id' => $user->id
            ]);
            
            return response()->json([
                'status' => 'success',
                'data' => [
                    'token' => $token,
                    'token_type' => 'bearer',
                    'expires_in' => JWTAuth::factory()->getTTL() * 60
                ]
            ], 200);

        } catch (JWTException $e) {
            return response()->json([
                'status' => 'error',
                'message' => 'Token cannot be refreshed'
            ], 401);
        }
    }

    /**
     * Get user profile (requires valid JWT)
     */
    public function profile(): JsonResponse
    {
        try {
            $user = JWTAuth::parseToken()->authenticate();
            
            return response()->json([
                'status' => 'success',
                'data' => [
                    'user' => [
                        'id' => $user->id,
                        'uuid' => $user->uuid,
                        'name' => $user->name,
                        'email' => $user->email,
                        'username' => $user->username,
                        'role' => $user->role,
                        'mobile_no' => $user->mobile_no,
                        'school_id' => $user->school_id,
                        'is_verified' => $user->is_verified,
                        'is_active' => $user->is_active,
                        'last_login' => $user->last_login_at,
                        'permissions' => $user->getAllPermissions()->pluck('name')
                    ]
                ]
            ], 200);

        } catch (JWTException $e) {
            return response()->json([
                'status' => 'error',
                'message' => 'User not found'
            ], 404);
        }
    }

    /**
     * Change password (requires valid JWT)
     */
    public function changePassword(Request $request): JsonResponse
    {
        try {
            $validator = Validator::make($request->all(), [
                'current_password' => 'required|string',
                'new_password' => [
                    'required',
                    'string',
                    'min:8',
                    'regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]/',
                    'confirmed'
                ],
                'new_password_confirmation' => 'required|string'
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'status' => 'error',
                    'errors' => $validator->errors()
                ], 422);
            }

            $user = JWTAuth::parseToken()->authenticate();

            if (!Hash::check($request->current_password, $user->password)) {
                return response()->json([
                    'status' => 'error',
                    'message' => 'Current password is incorrect'
                ], 400);
            }

            $user->update([
                'password' => Hash::make($request->new_password),
                'password_changed_at' => now(),
                'must_change_password' => false
            ]);

            $this->logSecurityEvent('password_changed', [
                'user_id' => $user->id,
                'ip_address' => $request->ip()
            ]);

            return response()->json([
                'status' => 'success',
                'message' => 'Password changed successfully'
            ], 200);

        } catch (JWTException $e) {
            return response()->json([
                'status' => 'error',
                'message' => 'User not found'
            ], 404);
        }
    }


    // This method  for forget password 
     
     /**
 * Step 1: Request password reset (send OTP to email)
 */

     public function requestPasswordReset(Request $request): JsonResponse
     {
      try{
        $validator = Validator::make($request->all(), [
            'email' => 'required|email|exists:users,email'
        ]);

           if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'message' => ' Request validation failed',
                'errors' => $validator->errors()
            ], 422);
        }

         $email = $request->email;
         $ipAddress = $request->ip();

         $rateLimitKey = 'password_reset:' . $ipAddress;

          if (RateLimiter::tooManyAttempts($rateLimitKey, 3)) { // 3 requests per hour
            $seconds = RateLimiter::availableIn($rateLimitKey);
            
            $this->logSecurityEvent('password_reset_rate_limit_exceeded', [
                'ip_address' => $ipAddress,
                'email' => $email
            ]);

            return response()->json([
                'status' => 'error',
                'message' => 'Too many password reset requests. Please try again later.',
                'retry_after' => $seconds
            ], 429);
        }

         $user = User::where('email', $email)->first();
          if (!$user->is_active || !$user->is_verified) {
            return response()->json([
                'status' => 'error',
                'message' => 'Account is not active or not verified'
            ], 403);
        }

        $otp = $this->generateSecureOTP();

        $user->update([
            'password_reset_otp' => Hash::make($otp),
            'password_reset_otp_expires_at' => now()->addMinutes(10),
            'password_reset_token' => Str::random(60) // Additional security token
        ]);

        // Send reset OTP email
        try {
            Mail::to($user->email)->send(new PasswordResetOtpMail($otp, $user->name));
            
            $this->logSecurityEvent('password_reset_requested', [
                'user_id' => $user->id,
                'email' => $user->email,
                'ip_address' => $ipAddress
            ]);

        } catch (\Exception $e) {
            \Log::error('Password reset email failed: ' . $e->getMessage());
        }

         RateLimiter::hit($rateLimitKey, 3600);

        return response()->json([
            'status' => 'success',
            'message' => 'Password reset OTP sent to your email',
            'data' => [
                'email' => $user->email,
                'otp_expires_in' => 600 // 10 minutes in seconds
            ]
        ], 200);

    }catch(\Exception $e){
     \Log::error('Password reset request error: ' . $e->getMessage());
      return response()->json([
            'status' => 'error',
            'message' => 'Failed to process password reset request'
        ], 500);
     }
    }

    /**
 * Step 2: Verify OTP for password reset
 */

    public function verifyPasswordResetOtp(Request $request): JsonResponse
    {
     try
     {
       $validator = Validator::make($request->all(), [
            'email' => 'required|email|exists:users,email',
            'otp' => 'required|string|size:6|regex:/^[0-9]{6}$/'
        ]);
          if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'message' => 'Validation failed',
                'errors' => $validator->errors()
            ], 422);
        }

        $user = User::where('email', $request->email)->first();
        $ipAddress = $request->ip();

          if (!$user->password_reset_otp || !$user->password_reset_otp_expires_at) {
            return response()->json([
                'status' => 'error',
                'message' => 'No active password reset request found'
            ], 400);
        }

        if (Carbon::parse($user->password_reset_otp_expires_at)->isPast()) {
            return response()->json([
                'status' => 'error',
                'message' => 'OTP has expired. Please request a new password reset.'
            ], 400);
        }


         if (!Hash::check($request->otp, $user->password_reset_otp)) {
            // Increment failed attempts
            $user->increment('failed_login_attempts');
            
            $this->logSecurityEvent('password_reset_otp_failed', [
                'user_id' => $user->id,
                'ip_address' => $ipAddress
            ]);

            return response()->json([
                'status' => 'error',
                'message' => 'Invalid OTP'
            ], 400);
        }

         $resetToken = Hash::make($user->password_reset_token . now()->timestamp);
        
        $user->update([
            'password_reset_verified' => true,
            'password_reset_verified_at' => now(),
            'temp_reset_token' => $resetToken
        ]);

        $this->logSecurityEvent('password_reset_otp_verified', [
            'user_id' => $user->id,
            'ip_address' => $ipAddress
        ]);

           return response()->json([
            'status' => 'success',
            'message' => 'OTP verified successfully. You can now reset your password.',
            'data' => [
                'reset_token' => $resetToken,
                'expires_in' => 900 // 15 minutes to complete password reset
            ]
        ], 200);

     }
     catch(\Exception $e){
       \Log::error('Password reset OTP verification error: ' . $e->getMessage());
        
        return response()->json([
            'status' => 'error',
            'message' => 'OTP verification failed'
        ], 500);
     }
    }
// Step 3: Reset password (after OTP verification)
    public function resetPassword(Request $request): JsonResponse
{
    try {
        $validator = Validator::make($request->all(), [
            'email' => 'required|email|exists:users,email',
            'reset_token' => 'required|string',
            'new_password' => [
                'required',
                'string',
                'min:8',
                'regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]/',
                'confirmed'
            ],
            'new_password_confirmation' => 'required|string'
        ], [
            'new_password.regex' => 'Password must contain at least one uppercase letter, one lowercase letter, one number and one special character'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'message' => 'Validation failed',
                'errors' => $validator->errors()
            ], 422);
        }

        $user = User::where('email', $request->email)->first();
        $ipAddress = $request->ip();

        // Check if OTP was verified
        if (!$user->password_reset_verified || !$user->temp_reset_token) {
            return response()->json([
                'status' => 'error',
                'message' => 'Password reset not authorized. Please verify OTP first.'
            ], 403);
        }

        // Check if reset token is valid and not expired (15 minutes)
        if (!$user->password_reset_verified_at || 
            Carbon::parse($user->password_reset_verified_at)->addMinutes(15)->isPast()) {
            return response()->json([
                'status' => 'error',
                'message' => 'Reset token expired. Please start the process again.'
            ], 400);
        }

        // Verify reset token
        if ($user->temp_reset_token !== $request->reset_token) {
            $this->logSecurityEvent('invalid_password_reset_token', [
                'user_id' => $user->id,
                'ip_address' => $ipAddress
            ]);

            return response()->json([
                'status' => 'error',
                'message' => 'Invalid reset token'
            ], 400);
        }

        // Reset password
        $user->update([
            'password' => Hash::make($request->new_password),
            'password_changed_at' => now(),
            'must_change_password' => false,
            // Clear reset data
            'password_reset_otp' => null,
            'password_reset_otp_expires_at' => null,
            'password_reset_token' => null,
            'password_reset_verified' => false,
            'password_reset_verified_at' => null,
            'temp_reset_token' => null,
            'failed_login_attempts' => 0
        ]);

        $this->logSecurityEvent('password_reset_completed', [
            'user_id' => $user->id,
            'ip_address' => $ipAddress
        ]);

        return response()->json([
            'status' => 'success',
            'message' => 'Password reset successfully. You can now login with your new password.'
        ], 200);

    } catch (\Exception $e) {
        \Log::error('Password reset error: ' . $e->getMessage());
        
        return response()->json([
            'status' => 'error',
            'message' => 'Password reset failed'
        ], 500);
    }
}


    /**
     * Generate secure OTP (6 digits)
     */
    private function generateSecureOTP(): string
    {
        return str_pad(random_int(0, 999999), 6, '0', STR_PAD_LEFT);
    }

    /**
     * Generate secure verification token (for additional security layer)
     */
    private function generateSecureVerificationToken(): string
    {
        return bin2hex(random_bytes(32));
    }

    /**
     * Generate unique username
     */
    private function generateUniqueUsername(string $baseUsername): string
    {
        $username = $baseUsername;
        $counter = 1;

        while (User::where('username', $username)->exists()) {
            $username = $baseUsername . $counter;
            $counter++;
        }

        return $username;
    }

    /**
     * Log security events
     */
    private function logSecurityEvent(string $event, array $data = []): void
    {
        \Log::channel('security')->info($event, array_merge([
            'timestamp' => now()->toISOString(),
            'event' => $event,
        ], $data));
    }

    /** 
     * 
     * This is separate method for Onboarding Student by admin
    */

    public function onboardStudentByAdmin(Request $request):JsonResponse
    {
        
    }

    
    

}