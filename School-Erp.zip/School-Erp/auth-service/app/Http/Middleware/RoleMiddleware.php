<?php
namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use Spatie\Permission\Traits\HasRoles;

class RoleMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @param  string  ...$roles
     * @return \Symfony\Component\HttpFoundation\Response
     */
    public function handle(Request $request, Closure $next, string ...$roles): Response
    {
        if (!$request->user()) {
            return response()->json([
                'status' => 'error',
                'message' => 'Unauthenticated'
            ], 401);
        }

        $user = $request->user();

        // Ensure the user model has the HasRoles trait
        if (!in_array(HasRoles::class, class_uses_recursive($user))) {
            \Log::error('User model does not use HasRoles trait');
            return response()->json([
                'status' => 'error',
                'message' => 'Server configuration error'
            ], 500);
        }

        // Check if user has any of the required roles
        try {
            foreach ($roles as $roleName) {
                if ($user->hasRole($roleName)) {
                    return $next($request);
                }
            }
        } catch (\Exception $e) {
            \Log::error('Role check error: ' . $e->getMessage());
            return response()->json([
                'status' => 'error',
                'message' => 'Permission check failed'
            ], 500);
        }

        return response()->json([
            'status' => 'error',
            'message' => 'Unauthorized. Insufficient permissions.'
        ], 403);
    }
}
