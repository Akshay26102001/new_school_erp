<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class SchoolAdminMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next): Response
    {
        $user = auth()->user();

        // Check if user is authenticated
        if (!$user) {
            return response()->json([
                'status' => 'error',
                'message' => 'Unauthenticated. Please login first.'
            ], 401);
        }

        // Check if user has the required role
        // Adjust the role check based on your User model implementation
        $allowedRoles = ['super_admin', 'school_admin', 'admin'];
        
        // If you're using Spatie Laravel Permission package
        if (method_exists($user, 'hasRole')) {
            $hasPermission = false;
            foreach ($allowedRoles as $role) {
                if ($user->hasRole($role)) {
                    $hasPermission = true;
                    break;
                }
            }
            
            if (!$hasPermission) {
                return response()->json([
                    'status' => 'error',
                    'message' => 'Unauthorized. Only school administrators are allowed to perform this action.'
                ], 403);
            }
        } 
        // If you're using a simple role field in users table
        elseif (isset($user->role)) {
            if (!in_array($user->role, $allowedRoles)) {
                return response()->json([
                    'status' => 'error',
                    'message' => 'Unauthorized. Only school administrators are allowed to perform this action.'
                ], 403);
            }
        }
        // Fallback - deny if no role system detected
        else {
            return response()->json([
                'status' => 'error',
                'message' => 'Role system not properly configured.'
            ], 500);
        }

        return $next($request);
    }
}