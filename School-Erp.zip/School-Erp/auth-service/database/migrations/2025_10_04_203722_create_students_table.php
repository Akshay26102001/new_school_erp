<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('students', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained('users')->onDelete('cascade');
            $table->foreignId('parent_id')->nullable()->constrained('parents_profiles')->onDelete('set null');

            $table->string('full_name');
            $table->enum('gender', ['male', 'female', 'other'])->nullable();
            $table->date('date_of_birth')->nullable();
            $table->string('blood_group')->nullable();
            $table->string('aadhar_number')->nullable()->unique();
            $table->string('category')->nullable();
            $table->string('religion')->nullable();
            $table->string('nationality')->nullable();

            $table->string('admission_number')->unique();
            $table->date('admission_date')->nullable();
            $table->string('class')->nullable();
            $table->string('section')->nullable();
            $table->string('previous_school')->nullable();
            $table->string('last_exam_result')->nullable();
            $table->string('student_roll_number')->nullable();

            $table->string('mobile_number')->nullable();
            $table->string('alternate_mobile')->nullable();
            $table->string('email')->nullable();
            $table->string('address_line1')->nullable();
            $table->string('address_line2')->nullable();
            $table->string('city')->nullable();
            $table->string('state')->nullable();
            $table->string('pincode')->nullable();

            $table->string('photo')->nullable();
            $table->string('birth_certificate')->nullable();
            $table->string('aadhar_card')->nullable();
            $table->string('transfer_certificate')->nullable();
            $table->text('remarks')->nullable();

            $table->boolean('status')->default(1); // active by default

            $table->timestamps();

            // Indexes for faster search
            $table->index('admission_number');
            $table->index('full_name');
            $table->index('class');
            $table->index('section');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('students');
    }
};
