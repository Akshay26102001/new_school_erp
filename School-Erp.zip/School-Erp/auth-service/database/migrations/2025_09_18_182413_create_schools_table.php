<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('schools', function (Blueprint $table) {
            $table->id();

            // Basic Information
            $table->string('name')->unique();
            $table->string('display_name')->nullable();
            $table->string('school_code')->unique();
            $table->string('registration_number')->nullable()->unique();

            // School Type & Education Level
            $table->enum('school_type', ['public', 'private', 'charter', 'international', 'boarding']);
            $table->enum('education_level', ['elementary', 'middle', 'high', 'k12', 'preschool']);

            // Contact Information
            $table->string('email')->unique();
            $table->string('phone', 20);
            $table->string('website')->nullable();

            // Address
            $table->string('address_line_1');
            $table->string('address_line_2')->nullable();
            $table->string('city', 100);
            $table->string('state', 100);
            $table->string('postal_code', 20);
            $table->string('country', 100);

            // Principal Information
            $table->string('principal_name');
            $table->string('principal_email');
            $table->string('principal_phone', 20);

            // Other Details
            $table->date('founded_date')->nullable();
            $table->string('board_affiliation', 100)->nullable();
            $table->string('medium_of_instruction', 100)->nullable();
            $table->text('description')->nullable();

            // Status & Verification
            $table->enum('status', ['pending', 'active', 'inactive'])->default('pending');
            $table->boolean('is_verified')->default(false);
            $table->timestamp('verification_date')->nullable();

            // Audit Columns
            $table->unsignedBigInteger('created_by')->nullable();
            $table->unsignedBigInteger('updated_by')->nullable();

            // Soft Deletes & Timestamps
            $table->softDeletes();
            $table->timestamps();

            // Foreign keys (optional, if users table exists)
            $table->foreign('created_by')->references('id')->on('users')->onDelete('set null');
            $table->foreign('updated_by')->references('id')->on('users')->onDelete('set null');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('schools');
    }
};