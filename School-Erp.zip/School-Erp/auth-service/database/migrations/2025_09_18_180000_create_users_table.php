<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('users', function (Blueprint $table) {
            $table->id();
            
            // Basic Information
            $table->uuid('uuid')->unique();
            $table->string('username', 50)->unique();
            $table->string('name');
            $table->string('email')->unique();
            $table->timestamp('email_verified_at')->nullable();
            $table->string('password');
            
            // Contact Information
            $table->string('mobile_no', 15)->nullable();
            $table->string('phone', 15)->nullable();
            
            // Role and School
            $table->enum('role', ['admin', 'staff', 'teacher', 'student'])->default('student');
            $table->string('school_id', 50)->nullable();
            
            // Security Fields
            $table->string('two_factor_secret')->nullable();
            $table->json('two_factor_recovery_codes')->nullable();
            $table->string('remember_token')->nullable();
            
            // Login Tracking
            $table->timestamp('last_login_at')->nullable();
            $table->string('last_login_ip', 45)->nullable();
            $table->integer('failed_login_attempts')->default(0);
            $table->timestamp('locked_until')->nullable();
            
            // Password Security
            $table->timestamp('password_changed_at')->nullable();
            $table->boolean('must_change_password')->default(false);
            
            // Account Status
            $table->boolean('is_verified')->default(false);
            $table->boolean('is_active')->default(false);
            
            // OTP and Email Verification
            $table->string('otp')->nullable();
            $table->timestamp('otp_expires_at')->nullable();
            $table->string('email_verification_token')->nullable();
            
            // Timestamps
            $table->timestamps();
            $table->softDeletes();
            
            // Indexes for performance
            $table->index('email');
            $table->index('username');
            $table->index('uuid');
            $table->index('school_id');
            $table->index('role');
            $table->index('is_active');
            $table->index('is_verified');
            $table->index(['email', 'is_active']);
            $table->index(['role', 'school_id']);
        });

        // Password reset tokens
        Schema::create('password_reset_tokens', function (Blueprint $table) {
            $table->string('email')->primary();
            $table->string('token');
            $table->timestamp('created_at')->nullable();
        });

        // Sessions
        Schema::create('sessions', function (Blueprint $table) {
            $table->string('id')->primary();
            $table->foreignId('user_id')->nullable()->index();
            $table->string('ip_address', 45)->nullable();
            $table->text('user_agent')->nullable();
            $table->longText('payload');
            $table->integer('last_activity')->index();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('sessions');
        Schema::dropIfExists('password_reset_tokens');
        Schema::dropIfExists('users');
    }
};