<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;

class RolePermissionSeeder extends Seeder
{
    public function run()
    {
        // Create all required roles
        Role::firstOrCreate(['name' => 'super-admin', 'guard_name' => 'web']);
        Role::firstOrCreate(['name' => 'admin', 'guard_name' => 'web']);        // Add this line
        Role::firstOrCreate(['name' => 'staff', 'guard_name' => 'web']);
        Role::firstOrCreate(['name' => 'teacher', 'guard_name' => 'web']);
        Role::firstOrCreate(['name' => 'student', 'guard_name' => 'web']);

        // Create permissions
        $permissions = [
            'manage users',
            'view dashboard',
            'manage students', 
            'view students',
            'create students',
            'edit students',
            'delete students',
            'manage staff',
            'view staff',
            'manage classes',
            'view reports',
            'manage settings',
            'school.create',
            'school.update',
            'school.view',
            'school.activate',
            'school.deactivate',
        ];

        foreach ($permissions as $permission) {
            Permission::firstOrCreate([
                'name' => $permission,
                'guard_name' => 'web'
            ]);
        }

        // Get roles
        $superAdminRole = Role::where('name', 'super-admin')->first();
        $adminRole = Role::where('name', 'admin')->first();           // Add this line
        $staffRole = Role::where('name', 'staff')->first();
        $teacherRole = Role::where('name', 'teacher')->first();
        $studentRole = Role::where('name', 'student')->first();

        // Assign permissions
        $superAdminRole->givePermissionTo(Permission::all());
        
        // Add permissions for admin role
        $adminRole->givePermissionTo([                               // Add this block
            'view dashboard',
            'manage students',
            'view students', 
            'create students',
            'edit students',
            'manage staff',
            'view staff',
            'manage classes',
            'view reports',
            'manage settings'
        ]);

        $staffRole->givePermissionTo([
            'view dashboard',
            'manage students',
            'view students', 
            'create students',
            'edit students',
            'view staff',
            'manage classes'
        ]);

        $teacherRole->givePermissionTo([
            'view dashboard',
            'view students',
            'view reports'
        ]);

        $studentRole->givePermissionTo([
            'view dashboard'
        ]);

        echo "Roles and permissions created successfully!\n";
    }
}