<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class SuperAdminSeeder extends Seeder
{
    public function run()
    {
        // Create super-admin role if it doesn't exist
        $superAdminRole = Role::firstOrCreate([
            'name' => 'super-admin',
            'guard_name' => 'web'
        ]);

        // Create super-admin specific permissions
        $superAdminPermissions = [
            'onboard schools',
            'manage all schools',
            'activate schools',
            'deactivate schools',
            'view all schools',
            'manage system settings',
            'view system logs',
            'manage super users'
        ];

        foreach ($superAdminPermissions as $permission) {
            Permission::firstOrCreate([
                'name' => $permission,
                'guard_name' => 'web'
            ]);
        }

        // Assign all permissions to super-admin
        $superAdminRole->givePermissionTo(Permission::all());

        // Create super-admin user
        $superAdminUser = User::firstOrCreate(
            ['email' => 'superadmin@schoolerp.com'],
            [
                'uuid' => Str::uuid(),
                'username' => 'superadmin',
                'name' => 'Super Administrator',
                'password' => Hash::make('SuperAdmin123!'),
                'role' => 'super-admin',
                'is_verified' => true,
                'is_active' => true,
                'email_verified_at' => now(),
                'password_changed_at' => now()
            ]
        );

        $superAdminUser->assignRole('super-admin');

        echo "Super Admin user created:\n";
        echo "Email: superadmin@schoolerp.com\n";
        echo "Password: SuperAdmin123!\n";
        echo "Please change this password after first login.\n";
    }
}