<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\SchoolController;
use App\Http\Controllers\StudentOnboardingController;
use App\Http\Controllers\ContactController;


// Health check and test routes
Route::get('/health', function () {
    return response()->json([
        'status' => 'healthy',
        'timestamp' => now()->toISOString(),
        'version' => '1.0.0'
    ]);
});

Route::get('/cors-test', function () {
    return response()->json([
        'message' => 'CORS is working!',
        'timestamp' => now(),
        'server' => 'Laravel ' . app()->version()
    ]);
});

// Public Authentication Routes
Route::prefix('auth')->group(function () {
    Route::post('/register', [AuthController::class, 'register']);
    Route::post('/verify-otp', [AuthController::class, 'verifyOtp']);
    Route::post('/resend-otp', [AuthController::class, 'resendOtp']);
    Route::post('/login', [AuthController::class, 'login']);
    Route::post('/password/request-reset', [AuthController::class, 'requestPasswordReset'])->name('password.request.reset');
    Route::post('/password/verify-otp', [AuthController::class, 'verifyPasswordResetOtp'])->name('password.verify.otp');
    Route::post('/password/reset', [AuthController::class, 'resetPassword'])->name('password.reset');
});

// Protected Authentication Routes
Route::middleware(['jwt.auth'])->prefix('auth')->group(function () {
    Route::get('/profile', [AuthController::class, 'profile']);
    Route::post('/logout', [AuthController::class, 'logout']);
    Route::post('/refresh', [AuthController::class, 'refresh']);
    Route::post('/change-password', [AuthController::class, 'changePassword']);
});


// School Management Routes (Protected by JWT)
Route::middleware(['jwt.auth'])->group(function () {
    // School listing and creation (Super Admin/Admin only - should be checked in Policy)
    Route::get('/schools', [SchoolController::class, 'index']);
    Route::post('/schools', [SchoolController::class, 'store']);
    
    // School activation/deactivation (Super Admin only - should be checked in Policy)
    Route::patch('/schools/{school}/activate', [SchoolController::class, 'activate']);
    Route::patch('/schools/{school}/deactivate', [SchoolController::class, 'deactivate']);
    
    // School access for all authenticated users
    Route::get('/schools/{school}', [SchoolController::class, 'show']);
    Route::put('/schools/{school}', [SchoolController::class, 'update']);


});




Route::middleware(['jwt.auth', 'school.admin'])->group(function () {
    Route::post('/students/onboard', [StudentOnboardingController::class, 'onboard']);
});


Route::post('/contact', [ContactController::class, 'store'])->name('contact.store');
