<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>ArambhTech - Innovating Digital Transformation</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700;800&family=Space+Grotesk:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
    body {
      background-color: #0f172a;
      color: #e2e8f0;
      font-family: 'Inter', sans-serif;
    }
    .section-title h2 {
      font-size: 3rem;
      font-weight: 800;
      background: linear-gradient(135deg, #2563eb, #06b6d4);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
    }
    .section-title p {
      color: #94a3b8;
      font-size: 1.2rem;
    }
    .p-4 {
      background: rgba(30, 41, 59, 0.7);
      border: 1px solid rgba(148, 163, 184, 0.2);
      border-radius: 20px;
      transition: all 0.3s ease;
    }
    .p-4:hover {
      transform: translateY(-10px);
      box-shadow: 0 15px 30px rgba(37, 99, 235, 0.3);
    }
  

        :root {
            --primary: #2563eb;
            --secondary: #06b6d4;
            --dark: #0f172a;
            --darker: #020617;
            --light: #f8fafc;
            --accent: #8b5cf6;
        }

        body {
            font-family: 'Inter', sans-serif;
            overflow-x: hidden;
            background: var(--darker);
            color: #e2e8f0;
        }

        h1, h2, h3, h4, h5 {
            font-family: 'Space Grotesk', sans-serif;
        }

        /* Navbar */
        .navbar {
            background: rgba(15, 23, 42, 0.95);
            backdrop-filter: blur(10px);
            padding: 1rem 0;
            transition: all 0.3s ease;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .navbar-brand {
            font-size: 1.8rem;
            font-weight: 800;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .nav-link {
            color: #cbd5e1 !important;
            font-weight: 500;
            margin: 0 0.5rem;
            transition: all 0.3s ease;
            position: relative;
        }

        .nav-link:hover {
            color: var(--secondary) !important;
        }

        .nav-link::after {
            content: '';
            position: absolute;
            bottom: -5px;
            left: 0;
            width: 0;
            height: 2px;
            background: var(--secondary);
            transition: width 0.3s ease;
        }

        .nav-link:hover::after {
            width: 100%;
        }

        .btn-nav {
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white;
            padding: 0.5rem 1.5rem;
            border-radius: 50px;
            border: none;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .btn-nav:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(37, 99, 235, 0.4);
        }

        /* Hero Section */
        .hero {
            min-height: 100vh;
            position: relative;
            display: flex;
            align-items: center;
            overflow: hidden;
            background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%);
        }

        .particle-bg {
            position: absolute;
            width: 100%;
            height: 100%;
            top: 0;
            left: 0;
            overflow: hidden;
        }

        .particle {
            position: absolute;
            background: var(--secondary);
            border-radius: 50%;
            animation: float 20s infinite;
        }

        @keyframes float {
            0%, 100% { transform: translate(0, 0) scale(1); opacity: 0.5; }
            50% { transform: translate(100px, 100px) scale(1.5); opacity: 0.8; }
        }

        .hero-content {
            position: relative;
            z-index: 2;
        }

        .hero h1 {
            font-size: 4rem;
            font-weight: 800;
            line-height: 1.2;
            background: linear-gradient(135deg, #fff, var(--secondary));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin-bottom: 1.5rem;
        }

        .typewriter {
            color: var(--secondary);
            font-size: 1.5rem;
            font-weight: 600;
            border-right: 3px solid var(--secondary);
            animation: blink 0.7s infinite;
        }

        @keyframes blink {
            50% { border-color: transparent; }
        }

        .hero-buttons {
            margin-top: 2rem;
        }

        .btn-primary-custom {
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white;
            padding: 1rem 2.5rem;
            border-radius: 50px;
            border: none;
            font-weight: 600;
            font-size: 1.1rem;
            margin: 0.5rem;
            transition: all 0.3s ease;
            box-shadow: 0 10px 25px rgba(37, 99, 235, 0.3);
        }

        .btn-primary-custom:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 35px rgba(37, 99, 235, 0.5);
        }

        .btn-outline-custom {
            background: transparent;
            color: white;
            padding: 1rem 2.5rem;
            border-radius: 50px;
            border: 2px solid var(--secondary);
            font-weight: 600;
            font-size: 1.1rem;
            margin: 0.5rem;
            transition: all 0.3s ease;
        }

        .btn-outline-custom:hover {
            background: var(--secondary);
            color: var(--darker);
            transform: translateY(-5px);
        }

        /* Section Styling */
        section {
            padding: 5rem 0;
            position: relative;
        }

        .section-title {
            text-align: center;
            margin-bottom: 3rem;
        }

        .section-title h2 {
            font-size: 3rem;
            font-weight: 800;
            margin-bottom: 1rem;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .section-title p {
            font-size: 1.2rem;
            color: #94a3b8;
        }

        /* About Section */
        .about-section {
            background: linear-gradient(180deg, var(--darker) 0%, var(--dark) 100%);
        }

        .founder-card {
            background: rgba(30, 41, 59, 0.5);
            border-radius: 20px;
            padding: 2rem;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(148, 163, 184, 0.1);
            transition: all 0.3s ease;
        }

        .founder-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 20px 40px rgba(37, 99, 235, 0.2);
        }

        .founder-img {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            border: 5px solid var(--secondary);
            margin-bottom: 1.5rem;
        }

        /* Service Cards */
        .service-card {
            background: rgba(30, 41, 59, 0.5);
            border-radius: 20px;
            padding: 2rem;
            text-align: center;
            transition: all 0.4s ease;
            border: 1px solid rgba(148, 163, 184, 0.1);
            backdrop-filter: blur(10px);
            cursor: pointer;
            height: 100%;
        }

        .service-card:hover {
            transform: translateY(-15px);
            box-shadow: 0 20px 40px rgba(37, 99, 235, 0.3);
            background: rgba(37, 99, 235, 0.1);
        }

        .service-icon {
            font-size: 3.5rem;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin-bottom: 1.5rem;
        }

        .service-card h4 {
            color: white;
            margin-bottom: 1rem;
            font-weight: 700;
        }

        /* Case Studies */
        .case-study-card {
            background: rgba(30, 41, 59, 0.5);
            border-radius: 20px;
            padding: 2rem;
            border: 1px solid rgba(148, 163, 184, 0.1);
            backdrop-filter: blur(10px);
            height: 100%;
        }

        .case-metric {
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white;
            padding: 1rem;
            border-radius: 10px;
            margin: 1rem 0;
            font-weight: 700;
            font-size: 1.2rem;
        }

        /* Tech Stack */
        .tech-icon {
            background: rgba(30, 41, 59, 0.5);
            border-radius: 15px;
            padding: 2rem;
            margin: 1rem;
            transition: all 0.3s ease;
            display: inline-flex;
            flex-direction: column;
            align-items: center;
            border: 1px solid rgba(148, 163, 184, 0.1);
        }

        .tech-icon:hover {
            transform: scale(1.1) rotate(5deg);
            background: rgba(37, 99, 235, 0.2);
        }

        .tech-icon i {
            font-size: 3rem;
            margin-bottom: 0.5rem;
            color: var(--secondary);
        }

        /* Counter */
        .counter-box {
            background: rgba(30, 41, 59, 0.5);
            border-radius: 15px;
            padding: 2rem;
            text-align: center;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(148, 163, 184, 0.1);
        }

        .counter-number {
            font-size: 3rem;
            font-weight: 800;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        /* Blog Cards */
        .blog-card {
            background: rgba(30, 41, 59, 0.5);
            border-radius: 20px;
            overflow: hidden;
            transition: all 0.3s ease;
            border: 1px solid rgba(148, 163, 184, 0.1);
            height: 100%;
        }

        .blog-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 20px 40px rgba(37, 99, 235, 0.3);
        }

        .blog-img {
            width: 100%;
            height: 200px;
            object-fit: cover;
        }

        .blog-content {
            padding: 1.5rem;
        }

        /* Testimonials */
        .testimonial-card {
            background: rgba(30, 41, 59, 0.5);
            border-radius: 20px;
            padding: 2rem;
            border: 1px solid rgba(148, 163, 184, 0.1);
            backdrop-filter: blur(10px);
            margin: 1rem;
        }

        .testimonial-avatar {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            border: 3px solid var(--secondary);
            margin-bottom: 1rem;
        }

        .stars {
            color: #fbbf24;
            font-size: 1.2rem;
            margin: 0.5rem 0;
        }

        /* Pricing */
        .pricing-card {
            background: rgba(30, 41, 59, 0.5);
            border-radius: 20px;
            padding: 2.5rem;
            border: 1px solid rgba(148, 163, 184, 0.1);
            backdrop-filter: blur(10px);
            transition: all 0.4s ease;
            height: 100%;
        }

        .pricing-card:hover {
            transform: translateY(-15px) scale(1.02);
            box-shadow: 0 25px 50px rgba(37, 99, 235, 0.4);
            border-color: var(--secondary);
        }

        .pricing-card.featured {
            background: linear-gradient(135deg, rgba(37, 99, 235, 0.2), rgba(6, 182, 212, 0.2));
            border: 2px solid var(--secondary);
        }

        .price {
            font-size: 3rem;
            font-weight: 800;
            color: var(--secondary);
        }

        /* Contact Form */
        .form-control, .form-select {
            background: rgba(30, 41, 59, 0.5);
            border: 1px solid rgba(148, 163, 184, 0.3);
            color: white;
            padding: 1rem;
            border-radius: 10px;
            margin-bottom: 1rem;
        }

        .form-control:focus, .form-select:focus {
            background: rgba(30, 41, 59, 0.7);
            border-color: var(--secondary);
            color: white;
            box-shadow: 0 0 0 0.2rem rgba(6, 182, 212, 0.25);
        }

        .form-control::placeholder {
            color: #94a3b8;
        }

        /* Footer */
        footer {
            background: var(--darker);
            padding: 3rem 0 1rem;
            border-top: 1px solid rgba(148, 163, 184, 0.1);
        }

        .footer-logo {
            font-size: 2rem;
            font-weight: 800;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .social-icons a {
            display: inline-block;
            width: 45px;
            height: 45px;
            background: rgba(30, 41, 59, 0.5);
            border-radius: 50%;
            text-align: center;
            line-height: 45px;
            margin: 0 0.5rem;
            color: var(--secondary);
            transition: all 0.3s ease;
            border: 1px solid rgba(148, 163, 184, 0.1);
        }

        .social-icons a:hover {
            background: var(--secondary);
            color: var(--darker);
            transform: translateY(-5px);
        }

        /* Modal */
        .modal-content {
            background: var(--dark);
            border: 1px solid rgba(148, 163, 184, 0.2);
            border-radius: 20px;
        }

        .modal-header {
            border-bottom: 1px solid rgba(148, 163, 184, 0.2);
        }

        .modal-footer {
            border-top: 1px solid rgba(148, 163, 184, 0.2);
        }

        /* Video Section */
        .video-wrapper {
            position: relative;
            padding-bottom: 56.25%;
            height: 0;
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
        }

        .video-wrapper iframe {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .hero h1 {
                font-size: 2.5rem;
            }

            .typewriter {
                font-size: 1.2rem;
            }

            .section-title h2 {
                font-size: 2rem;
            }
        }

        /* Scroll Progress Bar */
        .progress-bar-container {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 4px;
            background: rgba(148, 163, 184, 0.1);
            z-index: 9999;
        }

        .progress-bar {
            height: 4px;
            background: linear-gradient(90deg, var(--primary), var(--secondary));
            width: 0%;
            transition: width 0.1s ease;
        }
       .hero-image-slider {
    position: relative;
    width: 100%;
    height: 65vh; /* Bigger image height */
    min-height: 480px; /* Works even on small screens */
    overflow: hidden;
    border-radius: 28px;
    box-shadow: 0 25px 70px rgba(37, 99, 235, 0.45);
    background: rgba(255,255,255,0.03);
    backdrop-filter: blur(4px);
}

.hero-image-slider img {
    position: absolute;
    width: 100%;
    height: 100%;
    object-fit: contain;  /* keeps quality */
    top: 0;
    left: 0;
    opacity: 0;
    transition: opacity 1.3s ease-in-out, transform 1.3s ease-in-out;
    transform: scale(1.05);
}

.hero-image-slider img.active {
    opacity: 1;
    transform: scale(1); /* smooth zoom effect */
}

@media (max-width: 768px) {
    .hero-image-slider {
        height: 45vh;
        min-height: 300px;
    }
}

.form-control.is-invalid,
.form-select.is-invalid {
    border-color: #dc3545;
    box-shadow: 0 0 0 0.2rem rgba(220, 53, 69, 0.25);
}

.animated-alert {
    animation: slideInDown 0.5s ease-out;
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    border-left: 4px solid;
}

.alert-success {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    border-color: #667eea;
}

.alert-danger {
    background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
    color: white;
    border-color: #f5576c;
}

.alert-success .btn-close,
.alert-danger .btn-close {
    filter: brightness(0) invert(1);
}

@keyframes slideInDown {
    from {
        opacity: 0;
        transform: translateY(-20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.spinner-border-sm {
    width: 1rem;
    height: 1rem;
    border-width: 0.15em;
}


    </style>
</head>
<body>
    <!-- Scroll Progress Bar -->
    <div class="progress-bar-container">
        <div class="progress-bar" id="progressBar"></div>
    </div>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark fixed-top">
        <div class="container">
            <a class="navbar-brand" href="#">ArambhTech</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="#about">About</a></li>
                    <li class="nav-item"><a class="nav-link" href="#services">Services</a></li>
                    <li class="nav-item"><a class="nav-link" href="#cases">Case Studies</a></li>
                    <li class="nav-item"><a class="nav-link" href="#tech">Tech Stack</a></li>
                    <li class="nav-item"><a class="nav-link" href="#blog">Blog</a></li>
                    <li class="nav-item"><a class="nav-link" href="#pricing">Pricing</a></li>
                    <li class="nav-item"><a class="nav-link" href="#contact">Contact</a></li>
                </ul>
                <button class="btn-nav ms-3">Get Free Demo</button>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="hero">
        <div class="particle-bg" id="particleBg"></div>
        <div class="container hero-content">
            <div class="row align-items-center">
                <div class="col-lg-7" data-aos="fade-right">
                    <h1>Innovating the Future of Digital Transformation</h1>
                    <p class="lead mb-4">We empower businesses with cutting-edge IT solutions that drive growth, efficiency, and innovation across education, healthcare, and enterprise sectors.</p>
                    <div class="typewriter" id="typewriter"></div>
                    <div class="hero-buttons">
                        <button class="btn-primary-custom">Get Free Demo</button>
                        <button class="btn-outline-custom">Explore Services</button>
                    </div>
                </div>
                <div class="col-lg-5" data-aos="fade-left">
                   <!-- <img src="/images/herohome.png" alt="Tech" class="img-fluid rounded" style="box-shadow: 0 20px 60px rgba(37, 99, 235, 0.4);">-->
                  <!--  <img src="images/herohome.png" alt="Tech" class="img-fluid rounded" style="box-shadow: 0 20px 60px rgba(37, 99, 235, 0.4);">-->
                  <div class="hero-image-slider">
                     <img src="images/herohome.png" class="slide active">
                     <img src="images/s1.jpg" class="slide">
                     <img src="images/s2.png" class="slide">
                     <img src="images/s3.png" class="slide">
                 </div>


                </div>
            </div>
        </div>
    </section>

    <!-- About Section -->
    <section id="about" class="about-section">
        <div class="container">
            <div class="section-title" data-aos="fade-up">
                <h2>About ArambhTech</h2>
                <p>Transforming Industries Through Innovation</p>
            </div>
            <div class="row">
                <div class="col-lg-6 mb-4" data-aos="fade-right">
                    <h3 class="mb-4">Our Mission</h3>
                    <p class="lead">At ArambhTech, we believe in the power of technology to transform industries and improve lives. Our mission is to deliver world-class IT solutions that empower educational institutions, healthcare providers, and businesses to achieve their digital transformation goals.</p>
                    <p>With over 8 years of experience and a team of passionate developers, designers, and strategists, we've successfully delivered 200+ projects across various sectors. We don't just build software – we create digital experiences that drive measurable results.</p>
                    <p>Our approach combines cutting-edge technology with deep industry expertise to deliver solutions that are scalable, secure, and user-friendly. From concept to deployment and beyond, we're your trusted partner in digital innovation.</p>
                </div>
                <div class="col-lg-6" data-aos="fade-left">
                    <div class="founder-card text-center">
                        <img src="<?php echo e(asset('images/ceo.png')); ?>" alt="Founder" class="founder-img mx-auto">
                        <h4>Sachin Tomar</h4>
                        <p class="text-secondary">Founder & CEO</p>
                        <blockquote class="mt-3">
                            <i class="fas fa-quote-left text-secondary me-2"></i>
                            Technology should serve humanity, not the other way around. Our goal is to create solutions that make complex processes simple and empower people to achieve more.
                            <i class="fas fa-quote-right text-secondary ms-2"></i>
                        </blockquote>
                        <p class="mt-3"><small>Before founding ArambhTech, Rajesh led engineering teams at top tech companies and holds a Master's in Computer Science from IIT Delhi. His vision has guided the company to become a trusted partner for 500+ organizations worldwide.</small></p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Services Section -->
    <section id="services" class="py-5">
        <div class="container">
            <div class="section-title" data-aos="fade-up">
                <h2>Our Services</h2>
                <p>Comprehensive IT Solutions for Every Need</p>
            </div>
            <div class="row g-4">
                <div class="col-lg-4 col-md-6" data-aos="zoom-in" data-aos-delay="100">
                    <div class="service-card" data-bs-toggle="modal" data-bs-target="#serviceModal1">
                        <i class="fas fa-school service-icon"></i>
                        <h4>School Management System</h4>
                        <p>Complete digital solution for educational institutions with student management, attendance tracking, online classes, fee management, and parent-teacher communication.</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6" data-aos="zoom-in" data-aos-delay="200">
                    <div class="service-card" data-bs-toggle="modal" data-bs-target="#serviceModal2">
                        <i class="fas fa-hospital service-icon"></i>
                        <h4>Hospital Management System</h4>
                        <p>End-to-end healthcare solution with patient records, appointment scheduling, billing, pharmacy management, lab integration, and telemedicine features.</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6" data-aos="zoom-in" data-aos-delay="300">
                    <div class="service-card" data-bs-toggle="modal" data-bs-target="#serviceModal3">
                        <i class="fas fa-mobile-alt service-icon"></i>
                        <h4>Mobile App Development</h4>
                        <p>Native and cross-platform mobile applications for iOS and Android with beautiful UI/UX, seamless performance, and powerful backend integration.</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6" data-aos="zoom-in" data-aos-delay="400">
                    <div class="service-card" data-bs-toggle="modal" data-bs-target="#serviceModal4">
                        <i class="fas fa-code service-icon"></i>
                        <h4>Custom Web Development</h4>
                        <p>Scalable web applications built with modern frameworks like React, Angular, and Vue.js, backed by robust Node.js, Java Spring Boot, or .NET architectures.</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6" data-aos="zoom-in" data-aos-delay="500">
                    <div class="service-card" data-bs-toggle="modal" data-bs-target="#serviceModal5">
                        <i class="fas fa-bullhorn service-icon"></i>
                        <h4>Marketing Automation</h4>
                        <p>Powerful CRM and marketing automation platform with email campaigns, lead tracking, analytics dashboard, and social media integration.</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6" data-aos="zoom-in" data-aos-delay="600">
                    <div class="service-card" data-bs-toggle="modal" data-bs-target="#serviceModal6">
                        <i class="fas fa-cloud service-icon"></i>
                        <h4>Cloud & AI Solutions</h4>
                        <p>Cloud migration, AWS/Azure deployment, AI-powered analytics, machine learning models, and data security solutions for modern enterprises.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Case Studies Section -->
    <section id="cases" class="py-5" style="background: var(--dark);">
        <div class="container">
            <div class="section-title" data-aos="fade-up">
                <h2>Success Stories</h2>
                <p>Real Results from Real Clients</p>
            </div>
            <div id="caseCarousel" class="carousel slide" data-bs-ride="carousel">
                <div class="carousel-indicators">
                    <button type="button" data-bs-target="#caseCarousel" data-bs-slide-to="0" class="active"></button>
                    <button type="button" data-bs-target="#caseCarousel" data-bs-slide-to="1"></button>
                    <button type="button" data-bs-target="#caseCarousel" data-bs-slide-to="2"></button>
                </div>
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <div class="row">
                            <div class="col-lg-10 mx-auto">
                                <div class="case-study-card">
                                    <h3 class="mb-4"><i class="fas fa-graduation-cap text-secondary me-2"></i>Global Academy - School Management Transformation</h3>
                                    <div class="row">
                                        <div class="col-md-4 mb-3">
                                            <h5 class="text-secondary">Problem</h5>
                                            <p>Managing 5,000+ students across 3 campuses with paper-based processes. High administrative overhead, poor parent communication, and difficulty tracking student progress.</p>
                                        </div>
                                        <div class="col-md-4 mb-3">
                                            <h5 class="text-secondary">Solution</h5>
                                            <p>Implemented comprehensive school management system with mobile apps for parents and teachers, automated attendance, fee collection, and real-time notifications.</p>
                                        </div>
                                        <div class="col-md-4 mb-3">
                                            <h5 class="text-secondary">Results</h5>
                                            <div class="case-metric">70% reduction in admin work</div>
                                            <div class="case-metric">95% parent satisfaction</div>
                                            <div class="case-metric">100% paperless in 6 months</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <div class="row">
                            <div class="col-lg-10 mx-auto">
                                <div class="case-study-card">
                                    <h3 class="mb-4"><i class="fas fa-heartbeat text-secondary me-2"></i>HealthCare Plus - Digital Hospital Revolution</h3>
                                    <div class="row">
                                        <div class="col-md-4 mb-3">
                                            <h5 class="text-secondary">Problem</h5>
                                            <p>250-bed hospital struggling with manual patient records, long wait times, pharmacy errors, and lack of integration between departments.</p>
                                        </div>
                                        <div class="col-md-4 mb-3">
                                            <h5 class="text-secondary">Solution</h5>
                                            <p>Deployed integrated hospital management system with electronic medical records, online appointments, automated billing, and lab/pharmacy integration.</p>
                                        </div>
                                        <div class="col-md-4 mb-3">
                                            <h5 class="text-secondary">Results</h5>
                                            <div class="case-metric">60% faster patient processing</div>
                                            <div class="case-metric">Zero medication errors</div>
                                            <div class="case-metric">40% revenue increase</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <div class="row">
                            <div class="col-lg-10 mx-auto">
                                <div class="case-study-card">
                                    <h3 class="mb-4"><i class="fas fa-shopping-cart text-secondary me-2"></i>RetailPro - E-Commerce & Marketing Automation</h3>
                                    <div class="row">
                                        <div class="col-md-4 mb-3">
                                            <h5 class="text-secondary">Problem</h5>
                                            <p>Fashion retail company with fragmented systems, manual marketing processes, poor customer insights, and declining online sales conversion rates.</p>
                                        </div>
                                        <div class="col-md-4 mb-3">
                                            <h5 class="text-secondary">Solution</h5>
                                            <p>Built custom e-commerce platform with AI-powered recommendations, automated email campaigns, customer segmentation, and analytics dashboard.</p>
                                        </div>
                                        <div class="col-md-4 mb-3">
                                            <h5 class="text-secondary">Results</h5>
                                            <div class="case-metric">150% increase in online sales</div>
                                            <div class="case-metric">3x email conversion rate</div>
                                            <div class="case-metric">85% customer retention</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <button class="carousel-control-prev" type="button" data-bs-target="#caseCarousel" data-bs-slide="prev">
                    <span class="carousel-control-prev-icon"></span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#caseCarousel" data-bs-slide="next">
                    <span class="carousel-control-next-icon"></span>
                </button>
            </div>
        </div>
    </section>

    <!-- Tech Stack Section -->
    <section id="tech" class="py-5">
        <div class="container">
            <div class="section-title" data-aos="fade-up">
                <h2>Our Tech Stack</h2>
                <p>Built with Industry-Leading Technologies</p>
            </div>
            <div class="text-center">
                <div class="tech-icon" data-aos="flip-left" data-aos-delay="100">
                    <i class="fab fa-java"></i>
                    <span>Java</span>
                </div>
                <div class="tech-icon" data-aos="flip-left" data-aos-delay="200">
                    <i class="fab fa-react"></i>
                    <span>React</span>
                </div>
                <div class="tech-icon" data-aos="flip-left" data-aos-delay="300">
                    <i class="fab fa-node-js"></i>
                    <span>Node.js</span>
                </div>
                <div class="tech-icon" data-aos="flip-left" data-aos-delay="400">
                    <i class="fab fa-angular"></i>
                    <span>Angular</span>
                </div>
                <div class="tech-icon" data-aos="flip-left" data-aos-delay="500">
                    <i class="fab fa-python"></i>
                    <span>Python</span>
                </div>
                <div class="tech-icon" data-aos="flip-left" data-aos-delay="600">
                    <i class="fab fa-aws"></i>
                    <span>AWS</span>
                </div>
                <div class="tech-icon" data-aos="flip-left" data-aos-delay="700">
                    <i class="fab fa-docker"></i>
                    <span>Docker</span>
                </div>
                <div class="tech-icon" data-aos="flip-left" data-aos-delay="800">
                    <i class="fab fa-vuejs"></i>
                    <span>Vue.js</span>
                </div>
                <div class="tech-icon" data-aos="flip-left" data-aos-delay="900">
                    <i class="fas fa-database"></i>
                    <span>MongoDB</span>
                </div>
                <div class="tech-icon" data-aos="flip-left" data-aos-delay="1000">
                    <i class="fas fa-server"></i>
                    <span>PostgreSQL</span>
                </div>
            </div>
        </div>
    </section>

    <!-- Why Choose Us Section -->
    <section class="py-5" style="background: var(--dark);">
        <div class="container">
            <div class="section-title" data-aos="fade-up">
                <h2>Why Choose ArambhTech</h2>
                <p>Your Success is Our Priority</p>
            </div>
            <div class="row g-4 mb-5">
                <div class="col-lg-3 col-md-6" data-aos="fade-up" data-aos-delay="100">
                    <div class="counter-box">
                        <i class="fas fa-users fa-3x text-secondary mb-3"></i>
                        <div class="counter-number" data-target="500">0</div>
                        <p class="mt-2">Happy Clients</p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6" data-aos="fade-up" data-aos-delay="200">
                    <div class="counter-box">
                        <i class="fas fa-project-diagram fa-3x text-secondary mb-3"></i>
                        <div class="counter-number" data-target="200">0</div>
                        <p class="mt-2">Projects Delivered</p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6" data-aos="fade-up" data-aos-delay="300">
                    <div class="counter-box">
                        <i class="fas fa-calendar-alt fa-3x text-secondary mb-3"></i>
                        <div class="counter-number" data-target="8">0</div>
                        <p class="mt-2">Years Experience</p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6" data-aos="fade-up" data-aos-delay="400">
                    <div class="counter-box">
                        <i class="fas fa-award fa-3x text-secondary mb-3"></i>
                        <div class="counter-number" data-target="15">0</div>
                        <p class="mt-2">Industry Awards</p>
                    </div>
                </div>
            </div>
            <div class="row g-4">
                <div class="col-lg-3 col-md-6" data-aos="zoom-in" data-aos-delay="100">
                    <div class="text-center p-4">
                        <i class="fas fa-headset fa-4x text-secondary mb-3"></i>
                        <h4>24/7 Support</h4>
                        <p>Round-the-clock technical support and maintenance to keep your systems running smoothly.</p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6" data-aos="zoom-in" data-aos-delay="200">
                    <div class="text-center p-4">
                        <i class="fas fa-cogs fa-4x text-secondary mb-3"></i>
                        <h4>Agile Process</h4>
                        <p>Iterative development with regular feedback loops ensuring your vision comes to life.</p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6" data-aos="zoom-in" data-aos-delay="300">
                    <div class="text-center p-4">
                        <i class="fas fa-shield-alt fa-4x text-secondary mb-3"></i>
                        <h4>Data Security</h4>
                        <p>Bank-level encryption, secure cloud infrastructure, and compliance with global standards.</p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6" data-aos="zoom-in" data-aos-delay="400">
                    <div class="text-center p-4">
                        <i class="fas fa-users-cog fa-4x text-secondary mb-3"></i>
                        <h4>Expert Team</h4>
                        <p>50+ certified developers, designers, and consultants with deep industry expertise.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Blog Section -->
    <section id="blog" class="py-5">
        <div class="container">
            <div class="section-title" data-aos="fade-up">
                <h2>Latest from Our Blog</h2>
                <p>Insights, Trends, and Tech Innovations</p>
            </div>
            <div class="row g-4" id="blogContainer">
                <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="100">
                    <div class="blog-card">
                        <img src="https://images.unsplash.com/photo-1488590528505-98d2b5aba04b?w=400" alt="AI in Education" class="blog-img">
                        <div class="blog-content">
                            <span class="badge bg-primary mb-2">AI & Education</span>
                            <h4>How AI is Revolutionizing Modern Education</h4>
                            <p class="text-secondary">Explore how artificial intelligence is transforming classrooms with personalized learning, automated grading, and intelligent tutoring systems.</p>
                            <small class="text-secondary"><i class="far fa-calendar me-2"></i>Oct 25, 2025</small>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="200">
                    <div class="blog-card">
                        <img src="https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=400" alt="Healthcare Tech" class="blog-img">
                        <div class="blog-content">
                            <span class="badge bg-success mb-2">Healthcare</span>
                            <h4>Digital Health Transformation in 2025</h4>
                            <p class="text-secondary">The latest trends in telemedicine, electronic health records, and AI-powered diagnostics reshaping the healthcare industry.</p>
                            <small class="text-secondary"><i class="far fa-calendar me-2"></i>Oct 20, 2025</small>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="300">
                    <div class="blog-card">
                        <img src="https://images.unsplash.com/photo-1461749280684-dccba630e2f6?w=400" alt="Web Development" class="blog-img">
                        <div class="blog-content">
                            <span class="badge bg-warning mb-2">Development</span>
                            <h4>Modern Web Stack: React, Node & Cloud</h4>
                            <p class="text-secondary">A comprehensive guide to building scalable web applications using modern JavaScript frameworks and cloud technologies.</p>
                            <small class="text-secondary"><i class="far fa-calendar me-2"></i>Oct 15, 2025</small>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 blog-extra" style="display: none;" data-aos="fade-up">
                    <div class="blog-card">
                        <img src="https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=400" alt="Data Analytics" class="blog-img">
                        <div class="blog-content">
                            <span class="badge bg-info mb-2">Analytics</span>
                            <h4>Big Data Analytics for Business Growth</h4>
                            <p class="text-secondary">Learn how data-driven insights can transform your business strategy and drive exponential growth.</p>
                            <small class="text-secondary"><i class="far fa-calendar me-2"></i>Oct 10, 2025</small>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 blog-extra" style="display: none;" data-aos="fade-up">
                    <div class="blog-card">
                        <img src="https://images.unsplash.com/photo-1563986768494-4dee2763ff3f?w=400" alt="Cybersecurity" class="blog-img">
                        <div class="blog-content">
                            <span class="badge bg-danger mb-2">Security</span>
                            <h4>Cybersecurity Best Practices for 2025</h4>
                            <p class="text-secondary">Essential security measures every business needs to protect against modern cyber threats.</p>
                            <small class="text-secondary"><i class="far fa-calendar me-2"></i>Oct 5, 2025</small>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 blog-extra" style="display: none;" data-aos="fade-up">
                    <div class="blog-card">
                        <img src="https://images.unsplash.com/photo-1519389950473-47ba0277781c?w=400" alt="Agile" class="blog-img">
                        <div class="blog-content">
                            <span class="badge bg-secondary mb-2">Methodology</span>
                            <h4>Mastering Agile Development in Teams</h4>
                            <p class="text-secondary">Best practices for implementing agile methodologies to accelerate project delivery and team collaboration.</p>
                            <small class="text-secondary"><i class="far fa-calendar me-2"></i>Sep 30, 2025</small>
                        </div>
                    </div>
                </div>
            </div>
            <div class="text-center mt-4">
                <button class="btn-primary-custom" id="loadMoreBtn">Load More Articles</button>
            </div>
        </div>
    </section>

    <!-- Testimonials Section -->
    <section class="py-5" style="background: var(--dark);">
        <div class="container">
            <div class="section-title" data-aos="fade-up">
                <h2>What Our Clients Say</h2>
                <p>Real Feedback from Real Partners</p>
            </div>
            <div id="testimonialCarousel" class="carousel slide" data-bs-ride="carousel">
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <div class="row">
                            <div class="col-lg-4 col-md-6 mx-auto">
                                <div class="testimonial-card text-center">
                                    <img src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200" alt="Client" class="testimonial-avatar mx-auto">
                                    <div class="stars">★★★★★</div>
                                    <p class="mt-3">"ArambhTech transformed our school operations completely. The management system they built is intuitive, powerful, and has saved us countless hours. Parent engagement has never been better!"</p>
                                    <h5 class="mt-3">Priya Sharma</h5>
                                    <small class="text-secondary">Principal, Global Academy</small>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <div class="row">
                            <div class="col-lg-4 col-md-6 mx-auto">
                                <div class="testimonial-card text-center">
                                    <img src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=200" alt="Client" class="testimonial-avatar mx-auto">
                                    <div class="stars">★★★★★</div>
                                    <p class="mt-3">"The hospital management system exceeded our expectations. Patient satisfaction has increased significantly, and our staff loves how easy it is to use. Highly recommended!"</p>
                                    <h5 class="mt-3">Dr. Amit Patel</h5>
                                    <small class="text-secondary">Director, HealthCare Plus</small>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <div class="row">
                            <div class="col-lg-4 col-md-6 mx-auto">
                                <div class="testimonial-card text-center">
                                    <img src="https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=200" alt="Client" class="testimonial-avatar mx-auto">
                                    <div class="stars">★★★★★</div>
                                    <p class="mt-3">"Our online sales tripled after implementing their e-commerce and marketing automation solution. The team was professional, responsive, and delivered beyond expectations."</p>
                                    <h5 class="mt-3">Sneha Reddy</h5>
                                    <small class="text-secondary">CEO, RetailPro Fashion</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <button class="carousel-control-prev" type="button" data-bs-target="#testimonialCarousel" data-bs-slide="prev">
                    <span class="carousel-control-prev-icon"></span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#testimonialCarousel" data-bs-slide="next">
                    <span class="carousel-control-next-icon"></span>
                </button>
            </div>
        </div>
    </section>

    <!-- Video Section -->
   <section class="py-5">
    <div class="container">
      <div class="section-title text-center mb-5">
        <h2>Our Core Strengths</h2>
        <p>What Makes ArambhTech Stand Out</p>
      </div>
      <div class="row g-4 text-center">
        <div class="col-lg-4 col-md-6">
          <div class="p-4">
            <i class="fas fa-rocket fa-3x text-info mb-3"></i>
            <h4>Innovative & Scalable Solutions</h4>
            <p>We build future-ready digital ecosystems designed to scale with your business growth.</p>
          </div>
        </div>
        <div class="col-lg-4 col-md-6">
          <div class="p-4">
            <i class="fas fa-shield-alt fa-3x text-info mb-3"></i>
            <h4>Enterprise-Grade Security</h4>
            <p>Protecting your data with advanced encryption, secure servers, and regular audits.</p>
          </div>
        </div>
        <div class="col-lg-4 col-md-6">
          <div class="p-4">
            <i class="fas fa-handshake fa-3x text-info mb-3"></i>
            <h4>Transparent Communication</h4>
            <p>Open collaboration and clear updates ensure we stay aligned with your vision.</p>
          </div>
        </div>
        <div class="col-lg-4 col-md-6">
          <div class="p-4">
            <i class="fas fa-lightbulb fa-3x text-info mb-3"></i>
            <h4>Custom Strategy for Every Client</h4>
            <p>Tailored digital solutions crafted to meet your unique business challenges.</p>
          </div>
        </div>
        <div class="col-lg-4 col-md-6">
          <div class="p-4">
            <i class="fas fa-cogs fa-3x text-info mb-3"></i>
            <h4>Agile & Reliable Delivery</h4>
            <p>Using agile methods for fast, flexible, and high-quality project completion.</p>
          </div>
        </div>
        <div class="col-lg-4 col-md-6">
          <div class="p-4">
            <i class="fas fa-globe fa-3x text-info mb-3"></i>
            <h4>Global Client Network</h4>
            <p>Trusted by 500+ companies worldwide across multiple industries.</p>
          </div>
        </div>
      </div>
    </div>
  </section>

    <!-- Our Process Section -->
    <section class="py-5" style="background: var(--dark);">
        <div class="container">
            <div class="section-title" data-aos="fade-up">
                <h2>Our Development Process</h2>
                <p>From Concept to Launch - A Proven Methodology</p>
            </div>
            <div class="row g-4">
                <div class="col-lg-3 col-md-6" data-aos="fade-up" data-aos-delay="100">
                    <div class="process-card text-center p-4">
                        <div class="process-number">01</div>
                        <i class="fas fa-lightbulb fa-3x text-secondary mb-3"></i>
                        <h4>Discovery & Planning</h4>
                        <p class="text-secondary">We dive deep into understanding your business goals, target audience, and project requirements through detailed workshops and research.</p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6" data-aos="fade-up" data-aos-delay="200">
                    <div class="process-card text-center p-4">
                        <div class="process-number">02</div>
                        <i class="fas fa-pencil-ruler fa-3x text-secondary mb-3"></i>
                        <h4>Design & Prototyping</h4>
                        <p class="text-secondary">Our designers create stunning UI/UX mockups and interactive prototypes, ensuring every pixel is perfect before development begins.</p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6" data-aos="fade-up" data-aos-delay="300">
                    <div class="process-card text-center p-4">
                        <div class="process-number">03</div>
                        <i class="fas fa-code fa-3x text-secondary mb-3"></i>
                        <h4>Development & Testing</h4>
                        <p class="text-secondary">Using agile sprints, we build your solution with clean code, rigorous testing, and continuous integration for quality assurance.</p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6" data-aos="fade-up" data-aos-delay="400">
                    <div class="process-card text-center p-4">
                        <div class="process-number">04</div>
                        <i class="fas fa-rocket fa-3x text-secondary mb-3"></i>
                        <h4>Launch & Support</h4>
                        <p class="text-secondary">Smooth deployment to production with training, documentation, and ongoing support to ensure your success long after launch.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Industry Expertise Section -->
    <section class="py-5">
        <div class="container">
            <div class="section-title" data-aos="fade-up">
                <h2>Industries We Serve</h2>
                <p>Specialized Solutions Across Multiple Sectors</p>
            </div>
            <div class="row g-4">
                <div class="col-lg-4 col-md-6" data-aos="zoom-in" data-aos-delay="100">
                    <div class="industry-card">
                        <div class="industry-icon">
                            <i class="fas fa-graduation-cap"></i>
                        </div>
                        <h4>Education</h4>
                        <p>Digital transformation for schools, universities, and e-learning platforms with LMS, student portals, and virtual classrooms.</p>
                        <ul class="text-secondary">
                            <li>K-12 Schools</li>
                            <li>Higher Education</li>
                            <li>Online Learning Platforms</li>
                            <li>Training Institutes</li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6" data-aos="zoom-in" data-aos-delay="200">
                    <div class="industry-card">
                        <div class="industry-icon">
                            <i class="fas fa-heartbeat"></i>
                        </div>
                        <h4>Healthcare</h4>
                        <p>HIPAA-compliant solutions for hospitals, clinics, and telemedicine with EMR, patient management, and billing systems.</p>
                        <ul class="text-secondary">
                            <li>Hospitals & Clinics</li>
                            <li>Diagnostic Centers</li>
                            <li>Telemedicine Platforms</li>
                            <li>Pharmacy Chains</li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6" data-aos="zoom-in" data-aos-delay="300">
                    <div class="industry-card">
                        <div class="industry-icon">
                            <i class="fas fa-shopping-cart"></i>
                        </div>
                        <h4>E-Commerce</h4>
                        <p>Scalable online stores with payment integration, inventory management, and AI-powered recommendations.</p>
                        <ul class="text-secondary">
                            <li>Retail Businesses</li>
                            <li>Fashion & Lifestyle</li>
                            <li>Electronics</li>
                            <li>Multi-vendor Marketplaces</li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6" data-aos="zoom-in" data-aos-delay="400">
                    <div class="industry-card">
                        <div class="industry-icon">
                            <i class="fas fa-building"></i>
                        </div>
                        <h4>Real Estate</h4>
                        <p>Property management systems, listing platforms, and CRM solutions for real estate businesses.</p>
                        <ul class="text-secondary">
                            <li>Property Developers</li>
                            <li>Real Estate Agents</li>
                            <li>Property Management</li>
                            <li>Rental Platforms</li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6" data-aos="zoom-in" data-aos-delay="500">
                    <div class="industry-card">
                        <div class="industry-icon">
                            <i class="fas fa-utensils"></i>
                        </div>
                        <h4>Food & Restaurant</h4>
                        <p>Online ordering systems, delivery platforms, table reservations, and restaurant management software.</p>
                        <ul class="text-secondary">
                            <li>Restaurants & Cafes</li>
                            <li>Food Delivery Apps</li>
                            <li>Cloud Kitchens</li>
                            <li>Catering Services</li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6" data-aos="zoom-in" data-aos-delay="600">
                    <div class="industry-card">
                        <div class="industry-icon">
                            <i class="fas fa-chart-line"></i>
                        </div>
                        <h4>Finance & Banking</h4>
                        <p>Secure fintech solutions including payment gateways, lending platforms, and financial management systems.</p>
                        <ul class="text-secondary">
                            <li>Banking Solutions</li>
                            <li>Payment Processing</li>
                            <li>Investment Platforms</li>
                            <li>Insurance Tech</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Team Section -->
    <section class="py-5" style="background: var(--dark);">
        <div class="container">
            <div class="section-title" data-aos="fade-up">
                <h2>Meet Our Expert Team</h2>
                <p>Passionate Professionals Driving Innovation</p>
            </div>
            <div class="row g-4">
                <div class="col-lg-3 col-md-6" data-aos="flip-left" data-aos-delay="100">
                    <div class="team-card text-center">
                        <img src="images/ceo.png" height="450px" alt="Team Member" class="team-img">
                        <h4 class="mt-3">Sachin Tomar</h4>
                        <p class="text-secondary mb-2">Founder & CEO</p>
                        <p class="small">15+ years in software architecture and leading tech teams at Fortune 500 companies.</p>
                        <div class="team-social">
                            <a href="#"><i class="fab fa-linkedin-in"></i></a>
                            <a href="#"><i class="fab fa-twitter"></i></a>
                            <a href="#"><i class="fab fa-github"></i></a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6" data-aos="flip-left" data-aos-delay="200">
                    <div class="team-card text-center">
                        <img src="images/it.png" height="400px" alt="Team Member" class="team-img">
                        <h4 class="mt-3">Akshay Upadhyay</h4>
                        <p class="text-secondary mb-2">CTO</p>
                        <p class="small">Cloud architecture expert with deep knowledge in AWS, Azure, and microservices design.</p>
                        <div class="team-social">
                            <a href="#"><i class="fab fa-linkedin-in"></i></a>
                            <a href="#"><i class="fab fa-twitter"></i></a>
                            <a href="#"><i class="fab fa-github"></i></a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6" data-aos="flip-left" data-aos-delay="300">
                    <div class="team-card text-center">
                        <img src="images/graphics.png" height="350px" alt="Team Member" class="team-img">
                        <h4 class="mt-3">Komal Khakare</h4>
                        <p class="text-secondary mb-2">Head of Design</p>
                        <p class="small">Award-winning UI/UX designer creating beautiful, user-centric digital experiences.</p>
                        <div class="team-social">
                            <a href="#"><i class="fab fa-linkedin-in"></i></a>
                            <a href="#"><i class="fab fa-dribbble"></i></a>
                            <a href="#"><i class="fab fa-behance"></i></a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6" data-aos="flip-left" data-aos-delay="400">
                    <div class="team-card text-center">
                        <img src="https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=300" alt="Team Member" class="team-img">
                        <h4 class="mt-3">Sneha Reddy</h4>
                        <p class="text-secondary mb-2">Head of Marketing</p>
                        <p class="small">Digital marketing strategist with proven track record in growth hacking and brand building.</p>
                        <div class="team-social">
                            <a href="#"><i class="fab fa-linkedin-in"></i></a>
                            <a href="#"><i class="fab fa-twitter"></i></a>
                            <a href="#"><i class="fab fa-instagram"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Client Logos Section -->
    <section class="py-5">
        <div class="container">
            <div class="section-title" data-aos="fade-up">
                <h2>Trusted by Leading Organizations</h2>
                <p>500+ Companies Choose ArambhTech</p>
            </div>
            <div class="row align-items-center justify-content-center g-4">
                <div class="col-lg-2 col-md-3 col-6 text-center" data-aos="fade-up" data-aos-delay="100">
                    <div class="client-logo">
                        <i class="fas fa-building fa-3x"></i>
                        <p class="mt-2 mb-0 small">Global Academy</p>
                    </div>
                </div>
                <div class="col-lg-2 col-md-3 col-6 text-center" data-aos="fade-up" data-aos-delay="200">
                    <div class="client-logo">
                        <i class="fas fa-hospital fa-3x"></i>
                        <p class="mt-2 mb-0 small">HealthCare Plus</p>
                    </div>
                </div>
                <div class="col-lg-2 col-md-3 col-6 text-center" data-aos="fade-up" data-aos-delay="300">
                    <div class="client-logo">
                        <i class="fas fa-store fa-3x"></i>
                        <p class="mt-2 mb-0 small">RetailPro</p>
                    </div>
                </div>
                <div class="col-lg-2 col-md-3 col-6 text-center" data-aos="fade-up" data-aos-delay="400">
                    <div class="client-logo">
                        <i class="fas fa-university fa-3x"></i>
                        <p class="mt-2 mb-0 small">TechBank</p>
                    </div>
                </div>
                <div class="col-lg-2 col-md-3 col-6 text-center" data-aos="fade-up" data-aos-delay="500">
                    <div class="client-logo">
                        <i class="fas fa-shopping-bag fa-3x"></i>
                        <p class="mt-2 mb-0 small">Fashion Hub</p>
                    </div>
                </div>
                <div class="col-lg-2 col-md-3 col-6 text-center" data-aos="fade-up" data-aos-delay="600">
                    <div class="client-logo">
                        <i class="fas fa-home fa-3x"></i>
                        <p class="mt-2 mb-0 small">PropTech Co</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Awards & Recognition Section -->
    <section class="py-5" style="background: var(--dark);">
        <div class="container">
            <div class="section-title" data-aos="fade-up">
                <h2>Awards & Recognition</h2>
                <p>Excellence Acknowledged by Industry Leaders</p>
            </div>
            <div class="row g-4">
                <div class="col-lg-3 col-md-6" data-aos="zoom-in" data-aos-delay="100">
                    <div class="award-card text-center">
                        <i class="fas fa-trophy fa-4x text-warning mb-3"></i>
                        <h5>Best IT Startup 2024</h5>
                        <p class="text-secondary small">Startup India Awards</p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6" data-aos="zoom-in" data-aos-delay="200">
                    <div class="award-card text-center">
                        <i class="fas fa-award fa-4x text-warning mb-3"></i>
                        <h5>Innovation Excellence</h5>
                        <p class="text-secondary small">Tech Innovation Summit 2024</p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6" data-aos="zoom-in" data-aos-delay="300">
                    <div class="award-card text-center">
                        <i class="fas fa-medal fa-4x text-warning mb-3"></i>
                        <h5>Top Developer Company</h5>
                        <p class="text-secondary small">Clutch.co 2024</p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6" data-aos="zoom-in" data-aos-delay="400">
                    <div class="award-card text-center">
                        <i class="fas fa-star fa-4x text-warning mb-3"></i>
                        <h5>Customer Choice Award</h5>
                        <p class="text-secondary small">Gartner Peer Insights 2024</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Technology Partners Section -->
    <section class="py-5">
        <div class="container">
            <div class="section-title" data-aos="fade-up">
                <h2>Our Technology Partners</h2>
                <p>Collaborating with Industry Giants</p>
            </div>
            <div class="row align-items-center justify-content-center g-4">
                <div class="col-lg-2 col-md-3 col-6 text-center" data-aos="fade-up">
                    <div class="partner-logo">
                        <i class="fab fa-aws fa-4x"></i>
                        <p class="mt-2 small">AWS Partner</p>
                    </div>
                </div>
                <div class="col-lg-2 col-md-3 col-6 text-center" data-aos="fade-up">
                    <div class="partner-logo">
                        <i class="fab fa-microsoft fa-4x"></i>
                        <p class="mt-2 small">Microsoft Partner</p>
                    </div>
                </div>
                <div class="col-lg-2 col-md-3 col-6 text-center" data-aos="fade-up">
                    <div class="partner-logo">
                        <i class="fab fa-google fa-4x"></i>
                        <p class="mt-2 small">Google Cloud</p>
                    </div>
                </div>
                <div class="col-lg-2 col-md-3 col-6 text-center" data-aos="fade-up">
                    <div class="partner-logo">
                        <i class="fab fa-docker fa-4x"></i>
                        <p class="mt-2 small">Docker Certified</p>
                    </div>
                </div>
                <div class="col-lg-2 col-md-3 col-6 text-center" data-aos="fade-up">
                    <div class="partner-logo">
                        <i class="fab fa-react fa-4x"></i>
                        <p class="mt-2 small">React Experts</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- FAQ Section -->
    <section class="py-5" style="background: var(--dark);">
        <div class="container">
            <div class="section-title" data-aos="fade-up">
                <h2>Frequently Asked Questions</h2>
                <p>Everything You Need to Know</p>
            </div>
            <div class="row">
                <div class="col-lg-8 mx-auto">
                    <div class="accordion" id="faqAccordion">
                        <div class="accordion-item" data-aos="fade-up">
                            <h2 class="accordion-header">
                                <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#faq1">
                                    What is the typical timeline for a custom software project?
                                </button>
                            </h2>
                            <div id="faq1" class="accordion-collapse collapse show" data-bs-parent="#faqAccordion">
                                <div class="accordion-body">
                                    Project timelines vary based on complexity and scope. A simple web application typically takes 2-3 months, while enterprise solutions may take 6-12 months. We follow agile methodology with 2-week sprints, delivering working features incrementally so you can see progress throughout development.
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item" data-aos="fade-up">
                            <h2 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq2">
                                    Do you provide post-launch support and maintenance?
                                </button>
                            </h2>
                            <div id="faq2" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                                <div class="accordion-body">
                                    Yes! We offer comprehensive support packages including 24/7 monitoring, bug fixes, security updates, feature enhancements, and performance optimization. Our support plans start from basic email support to dedicated account managers for enterprise clients.
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item" data-aos="fade-up">
                            <h2 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq3">
                                    How do you ensure data security and privacy?
                                </button>
                            </h2>
                            <div id="faq3" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                                <div class="accordion-body">
                                    Security is our top priority. We implement industry-standard encryption (SSL/TLS), secure authentication (OAuth 2.0, JWT), regular security audits, GDPR compliance, and follow OWASP guidelines. All our cloud deployments include DDoS protection, firewalls, and automated backups.
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item" data-aos="fade-up">
                            <h2 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq4">
                                    Can you integrate with our existing systems?
                                </button>
                            </h2>
                            <div id="faq4" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                                <div class="accordion-body">
                                    Absolutely! We have extensive experience integrating with CRM systems (Salesforce, HubSpot), payment gateways (Stripe, PayPal), ERPs (SAP, Oracle), and various third-party APIs. We'll conduct a thorough analysis of your current infrastructure and design seamless integrations.
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item" data-aos="fade-up">
                            <h2 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq5">
                                    What makes ArambhTech different from other IT companies?
                                </button>
                            </h2>
                            <div id="faq5" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                                <div class="accordion-body">
                                    Our unique blend of technical expertise, industry knowledge, and client-focused approach sets us apart. We don't just code - we understand your business challenges and deliver solutions that drive real results. With 500+ satisfied clients, 8+ years of experience, and a 98% client retention rate, we've proven our commitment to excellence.
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Call to Action Section -->
    <section class="py-5" style="background: linear-gradient(135deg, #2563eb, #06b6d4); position: relative; overflow: hidden;">
        <div style="position: absolute; width: 100%; height: 100%; opacity: 0.1;">
            <div style="position: absolute; width: 300px; height: 300px; background: white; border-radius: 50%; top: -100px; right: -100px;"></div>
            <div style="position: absolute; width: 200px; height: 200px; background: white; border-radius: 50%; bottom: -50px; left: -50px;"></div>
        </div>
        <div class="container text-center" style="position: relative; z-index: 2;">
            <div data-aos="zoom-in">
                <h2 style="color: white; font-size: 3rem; margin-bottom: 1.5rem;">Ready to Transform Your Business?</h2>
                <p style="color: rgba(255,255,255,0.9); font-size: 1.3rem; margin-bottom: 2rem;">Let's discuss how we can help you achieve your digital transformation goals</p>
                <button class="btn btn-light btn-lg px-5 py-3 me-3" style="font-weight: 600; border-radius: 50px;">Schedule Free Consultation</button>
                <button class="btn btn-outline-light btn-lg px-5 py-3" style="font-weight: 600; border-radius: 50px; border: 2px solid white;">View Our Portfolio</button>
            </div>
        </div>
    </section>

    <!-- Pricing Section -->
    <section id="pricing" class="py-5" style="background: var(--dark);">
        <div class="container">
            <div class="section-title" data-aos="fade-up">
                <h2>Flexible Pricing Plans</h2>
                <p>Choose the Perfect Plan for Your Needs</p>
            </div>
            <div class="row g-4">
                <div class="col-lg-4" data-aos="fade-up" data-aos-delay="100">
                    <div class="pricing-card">
                        <h3 class="mb-3">Starter</h3>
                        <div class="price mb-3">$999<span style="font-size: 1rem; color: #94a3b8;">/month</span></div>
                        <p class="text-secondary mb-4">Perfect for small businesses and startups</p>
                        <ul class="list-unstyled mb-4">
                            <li class="mb-2"><i class="fas fa-check text-secondary me-2"></i>Basic Web Application</li>
                            <li class="mb-2"><i class="fas fa-check text-secondary me-2"></i>Mobile Responsive Design</li>
                            <li class="mb-2"><i class="fas fa-check text-secondary me-2"></i>Up to 5 User Accounts</li>
                            <li class="mb-2"><i class="fas fa-check text-secondary me-2"></i>Email Support</li>
                            <li class="mb-2"><i class="fas fa-check text-secondary me-2"></i>Monthly Updates</li>
                            <li class="mb-2"><i class="fas fa-check text-secondary me-2"></i>Basic Analytics</li>
                        </ul>
                        <button class="btn-primary-custom w-100">Get Started</button>
                    </div>
                </div>
                <div class="col-lg-4" data-aos="fade-up" data-aos-delay="200">
                    <div class="pricing-card featured">
                        <div class="badge bg-secondary mb-3">Most Popular</div>
                        <h3 class="mb-3">Professional</h3>
                        <div class="price mb-3">$2,499<span style="font-size: 1rem; color: #94a3b8;">/month</span></div>
                        <p class="text-secondary mb-4">Ideal for growing businesses</p>
                        <ul class="list-unstyled mb-4">
                            <li class="mb-2"><i class="fas fa-check text-secondary me-2"></i>Custom Web & Mobile App</li>
                            <li class="mb-2"><i class="fas fa-check text-secondary me-2"></i>Advanced Features</li>
                            <li class="mb-2"><i class="fas fa-check text-secondary me-2"></i>Up to 50 User Accounts</li>
                            <li class="mb-2"><i class="fas fa-check text-secondary me-2"></i>Priority Support 24/7</li>
                            <li class="mb-2"><i class="fas fa-check text-secondary me-2"></i>Weekly Updates</li>
                            <li class="mb-2"><i class="fas fa-check text-secondary me-2"></i>Advanced Analytics & Reports</li>
                            <li class="mb-2"><i class="fas fa-check text-secondary me-2"></i>API Integration</li>
                            <li class="mb-2"><i class="fas fa-check text-secondary me-2"></i>Cloud Hosting Included</li>
                        </ul>
                        <button class="btn-primary-custom w-100">Get Started</button>
                    </div>
                </div>
                <div class="col-lg-4" data-aos="fade-up" data-aos-delay="300">
                    <div class="pricing-card">
                        <h3 class="mb-3">Enterprise</h3>
                        <div class="price mb-3">Custom<span style="font-size: 1rem; color: #94a3b8;"></span></div>
                        <p class="text-secondary mb-4">For large organizations with specific needs</p>
                        <ul class="list-unstyled mb-4">
                            <li class="mb-2"><i class="fas fa-check text-secondary me-2"></i>Fully Custom Solution</li>
                            <li class="mb-2"><i class="fas fa-check text-secondary me-2"></i>Unlimited Users</li>
                            <li class="mb-2"><i class="fas fa-check text-secondary me-2"></i>Dedicated Account Manager</li>
                            <li class="mb-2"><i class="fas fa-check text-secondary me-2"></i>24/7 Premium Support</li>
                            <li class="mb-2"><i class="fas fa-check text-secondary me-2"></i>Daily Updates & Monitoring</li>
                            <li class="mb-2"><i class="fas fa-check text-secondary me-2"></i>Custom Analytics Dashboard</li>
                            <li class="mb-2"><i class="fas fa-check text-secondary me-2"></i>Advanced Security Features</li>
                            <li class="mb-2"><i class="fas fa-check text-secondary me-2"></i>On-Premise Deployment Option</li>
                            <li class="mb-2"><i class="fas fa-check text-secondary me-2"></i>Training & Onboarding</li>
                        </ul>
                        <button class="btn-primary-custom w-100">Contact Sales</button>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Contact Section -->
    <section id="contact" class="py-5">
        <div class="container">
            <div class="section-title" data-aos="fade-up">
                <h2>Get In Touch</h2>
                <p>Let's Build Something Amazing Together</p>
            </div>
            <div class="row g-4">
                <div class="col-lg-6" data-aos="fade-right">
                    <h3 class="mb-4">Send us a Message</h3>
                   <form id="contactForm" method="POST" action="<?php echo e(route('contact.store')); ?>">
    <?php echo csrf_field(); ?>
    <div class="mb-3">
        <input type="text" name="name" class="form-control" placeholder="Your Name" required>
    </div>
    <div class="mb-3">
        <input type="email" name="email" class="form-control" placeholder="Your Email" required>
    </div>
    <div class="mb-3">
        <input type="tel" name="phone" class="form-control" placeholder="Phone Number">
    </div>
    <div class="mb-3">
        <select name="service" class="form-select">
            <option value="">Select Service</option>
            <option>School Management System</option>
            <option>Hospital Management System</option>
            <option>Mobile App Development</option>
            <option>Web Development</option>
            <option>Marketing Automation</option>
            <option>Cloud & AI Solutions</option>
        </select>
    </div>
    <div class="mb-3">
        <textarea name="message" class="form-control" rows="5" placeholder="Tell us about your project..." required></textarea>
    </div>
    <button type="submit" class="btn-primary-custom w-100">Send Message</button>
</form>

                </div>
                <div class="col-lg-6" data-aos="fade-left">
                    <h3 class="mb-4">Contact Information</h3>
                    <div class="mb-4">
                        <h5><i class="fas fa-map-marker-alt text-secondary me-2"></i>Address</h5>
                        <p class="text-secondary">ArambhTech IT Solutions<br>
                        Tower B, Cyber Park, Malviya Nagar<br>
                        Jaipur, Rajasthan 302017, India</p>
                    </div>
                    <div class="mb-4">
                        <h5><i class="fas fa-phone text-secondary me-2"></i>Phone</h5>
                        <p class="text-secondary">+91 78953 41612<br>
                        +91 79035 41590 </p>
                    </div>
                    <div class="mb-4">
                        <h5><i class="fas fa-envelope text-secondary me-2"></i>Email</h5>
                        <p class="text-secondary">info@ArambhTech.com<br>
                        sales@ArambhTech.com</p>
                    </div>
                    <div class="mb-4">
                        <h5><i class="fas fa-clock text-secondary me-2"></i>Business Hours</h5>
                        <p class="text-secondary">Monday - Friday: 9:00 AM - 6:00 PM<br>
                        Saturday: 10:00 AM - 1:00 PM<br>
                        Sunday: Closed</p>
                    </div>
                    <div>
                        <h5 class="mb-3">Follow Us</h5>
                        <div class="social-icons">
                            <a href="#"><i class="fab fa-facebook-f"></i></a>
                            <a href="#"><i class="fab fa-twitter"></i></a>
                            <a href="#"><i class="fab fa-linkedin-in"></i></a>
                            <a href="#"><i class="fab fa-instagram"></i></a>
                            <a href="#"><i class="fab fa-github"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Newsletter Section -->
    <section class="py-5" style="background: linear-gradient(135deg, var(--primary), var(--secondary));">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6 mb-4 mb-lg-0" data-aos="fade-right">
                    <h2 style="color: white;">Subscribe to Our Newsletter</h2>
                    <p style="color: rgba(255,255,255,0.9);">Get the latest tech insights, industry trends, and exclusive offers delivered to your inbox.</p>
                </div>
                <div class="col-lg-6" data-aos="fade-left">
                    <div class="input-group">
                        <input type="email" class="form-control" placeholder="Enter your email" style="padding: 1rem; border: none;">
                        <button class="btn btn-dark px-4" type="button" style="font-weight: 600;">Subscribe</button>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer>
        <div class="container">
            <div class="row g-4">
                <div class="col-lg-4 col-md-6">
                    <div class="footer-logo mb-3">ArambhTech</div>
                    <p class="text-secondary">Innovating the future of digital transformation with cutting-edge IT solutions for education, healthcare, and enterprise sectors.</p>
                    <div class="social-icons mt-4">
                        <a href="#"><i class="fab fa-facebook-f"></i></a>
                        <a href="#"><i class="fab fa-twitter"></i></a>
                        <a href="#"><i class="fab fa-linkedin-in"></i></a>
                        <a href="#"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
                <div class="col-lg-2 col-md-6">
                    <h5 class="mb-3">Quick Links</h5>
                    <ul class="list-unstyled">
                        <li class="mb-2"><a href="#about" class="text-secondary text-decoration-none">About Us</a></li>
                        <li class="mb-2"><a href="#services" class="text-secondary text-decoration-none">Services</a></li>
                        <li class="mb-2"><a href="#cases" class="text-secondary text-decoration-none">Case Studies</a></li>
                        <li class="mb-2"><a href="#tech" class="text-secondary text-decoration-none">Tech Stack</a></li>
                        <li class="mb-2"><a href="#blog" class="text-secondary text-decoration-none">Blog</a></li>
                    </ul>
                </div>
                <div class="col-lg-3 col-md-6">
                    <h5 class="mb-3">Services</h5>
                    <ul class="list-unstyled">
                        <li class="mb-2"><a href="#" class="text-secondary text-decoration-none">School Management</a></li>
                        <li class="mb-2"><a href="#" class="text-secondary text-decoration-none">Hospital Management</a></li>
                        <li class="mb-2"><a href="#" class="text-secondary text-decoration-none">Mobile Apps</a></li>
                        <li class="mb-2"><a href="#" class="text-secondary text-decoration-none">Web Development</a></li>
                        <li class="mb-2"><a href="#" class="text-secondary text-decoration-none">Cloud Solutions</a></li>
                    </ul>
                </div>
                <div class="col-lg-3 col-md-6">
                    <h5 class="mb-3">Contact</h5>
                    <ul class="list-unstyled">
                        <li class="mb-2 text-secondary"><i class="fas fa-map-marker-alt me-2"></i>Jaipur, Rajasthan</li>
                        <li class="mb-2"><a href="tel:+911411234567" class="text-secondary text-decoration-none"><i class="fas fa-phone me-2"></i>+91 141 123 4567</a></li>
                        <li class="mb-2"><a href="mailto:info@ArambhTech.com" class="text-secondary text-decoration-none"><i class="fas fa-envelope me-2"></i>info@ArambhTech.com</a></li>
                    </ul>
                </div>
            </div>
            <hr style="border-color: rgba(148, 163, 184, 0.2); margin: 2rem 0;">
            <div class="text-center text-secondary">
                <p>&copy; 2025 ArambhTech IT Solutions. All rights reserved. | <a href="#" class="text-secondary">Privacy Policy</a> | <a href="#" class="text-secondary">Terms of Service</a></p>
            </div>
        </div>
    </footer>

    <!-- Service Modals -->
    <div class="modal fade" id="serviceModal1" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-school text-secondary me-2"></i>School Management System</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <img src="https://images.unsplash.com/photo-1503676260728-1c00da094a0b?w=800" alt="School" class="img-fluid rounded mb-3">
                    <h5>Complete Digital Solution for Educational Institutions</h5>
                    <p>Our comprehensive school management system streamlines every aspect of educational administration, from admission to graduation.</p>
                    <h6 class="mt-4">Key Features:</h6>
                    <ul>
                        <li><strong>Student Information System:</strong> Complete student profiles, academic records, and progress tracking</li>
                        <li><strong>Attendance Management:</strong> Automated attendance tracking with biometric integration and instant parent notifications</li>
                        <li><strong>Online Classes:</strong> Integrated virtual classroom with video conferencing, assignments, and assessments</li>
                        <li><strong>Fee Management:</strong> Online fee payment, automated reminders, and financial reporting</li>
                        <li><strong>Parent Portal:</strong> Real-time updates on child's progress, attendance, and school announcements</li>
                        <li><strong>Teacher Dashboard:</strong> Lesson planning, grade management, and student performance analytics</li>
                        <li><strong>Library Management:</strong> Digital catalog, book issue/return tracking, and overdue notifications</li>
                        <li><strong>Transport Management:</strong> GPS tracking, route optimization, and student pickup/drop alerts</li>
                    </ul>
                    <h6 class="mt-4">Benefits:</h6>
                    <div class="row">
                        <div class="col-md-6">
                            <p><i class="fas fa-check-circle text-secondary me-2"></i>70% reduction in administrative work</p>
                            <p><i class="fas fa-check-circle text-secondary me-2"></i>Improved parent-teacher communication</p>
                        </div>
                        <div class="col-md-6">
                            <p><i class="fas fa-check-circle text-secondary me-2"></i>100% paperless operations</p>
                            <p><i class="fas fa-check-circle text-secondary me-2"></i>Enhanced student learning outcomes</p>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn-primary-custom">Request Demo</button>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="serviceModal2" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-hospital text-secondary me-2"></i>Hospital Management System</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <img src="https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?w=800" alt="Hospital" class="img-fluid rounded mb-3">
                    <h5>End-to-End Healthcare Management Solution</h5>
                    <p>Transform your healthcare facility with our intelligent hospital management system designed for efficiency, patient care, and operational excellence.</p>
                    <h6 class="mt-4">Key Features:</h6>
                    <ul>
                        <li><strong>Electronic Medical Records (EMR):</strong> Secure digital patient records with complete medical history</li>
                        <li><strong>Appointment Scheduling:</strong> Online booking system with automated reminders and calendar management</li>
                        <li><strong>Billing & Insurance:</strong> Integrated billing with insurance claim processing and payment tracking</li>
                        <li><strong>Pharmacy Management:</strong> Inventory control, prescription management, and automated reordering</li>
                        <li><strong>Laboratory Integration:</strong> Digital lab reports, test tracking, and result notifications</li>
                        <li><strong>Telemedicine:</strong> Virtual consultation platform with video calling and e-prescription</li>
                        <li><strong>Ward Management:</strong> Bed allocation, patient admission/discharge, and nursing care tracking</li>
                        <li><strong>Analytics Dashboard:</strong> Real-time insights on operations, revenue, and patient satisfaction</li>
                    </ul>
                    <h6 class="mt-4">Benefits:</h6>
                    <div class="row">
                        <div class="col-md-6">
                            <p><i class="fas fa-check-circle text-secondary me-2"></i>60% faster patient processing</p>
                            <p><i class="fas fa-check-circle text-secondary me-2"></i>Zero medication errors</p>
                        </div>
                        <div class="col-md-6">
                            <p><i class="fas fa-check-circle text-secondary me-2"></i>40% revenue increase</p>
                            <p><i class="fas fa-check-circle text-secondary me-2"></i>Enhanced patient satisfaction</p>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn-primary-custom">Request Demo</button>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="serviceModal3" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-mobile-alt text-secondary me-2"></i>Mobile App Development</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <img src="https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?w=800" alt="Mobile" class="img-fluid rounded mb-3">
                    <h5>Native & Cross-Platform Mobile Solutions</h5>
                    <p>Build powerful, scalable mobile applications that deliver exceptional user experiences on iOS and Android platforms.</p>
                    <h6 class="mt-4">Our Expertise:</h6>
                    <ul>
                        <li><strong>Native iOS Development:</strong> Swift and Objective-C for high-performance iPhone and iPad apps</li>
                        <li><strong>Native Android Development:</strong> Kotlin and Java for optimal Android experience</li>
                        <li><strong>Cross-Platform:</strong> React Native and Flutter for cost-effective multi-platform apps</li>
                        <li><strong>UI/UX Design:</strong> Beautiful, intuitive interfaces following platform design guidelines</li>
                        <li><strong>Backend Integration:</strong> RESTful APIs, real-time data sync, and cloud storage</li>
                        <li><strong>Push Notifications:</strong> Engage users with timely, personalized messages</li>
                        <li><strong>App Store Optimization:</strong> Launch strategy and ongoing optimization for visibility</li>
                        <li><strong>Maintenance & Support:</strong> Regular updates, bug fixes, and feature enhancements</li>
                    </ul>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn-primary-custom">Request Demo</button>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="serviceModal4" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-code text-secondary me-2"></i>Custom Web Development</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <img src="https://images.unsplash.com/photo-1547658719-da2b51169166?w=800" alt="Web Dev" class="img-fluid rounded mb-3">
                    <h5>Scalable Web Applications for Modern Businesses</h5>
                    <p>We build enterprise-grade web applications using cutting-edge technologies and best practices.</p>
                    <h6 class="mt-4">Technology Stack:</h6>
                    <ul>
                        <li><strong>Frontend:</strong> React.js, Angular, Vue.js with responsive design and progressive web app capabilities</li>
                        <li><strong>Backend:</strong> Node.js, Java Spring Boot, .NET Core for robust server-side logic</li>
                        <li><strong>Database:</strong> PostgreSQL, MongoDB, MySQL with optimized queries and data modeling</li>
                        <li><strong>Cloud Hosting:</strong> AWS, Azure, Google Cloud with auto-scaling and load balancing</li>
                        <li><strong>DevOps:</strong> Docker, Kubernetes, CI/CD pipelines for seamless deployment</li>
                        <li><strong>Security:</strong> OAuth, JWT, encryption, and compliance with security standards</li>
                    </ul>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn-primary-custom">Request Demo</button>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="serviceModal5" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-bullhorn text-secondary me-2"></i>Marketing Automation & CRM</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <img src="https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800" alt="Marketing" class="img-fluid rounded mb-3">
                    <h5>Powerful Marketing Automation Platform</h5>
                    <p>Streamline your marketing efforts and boost conversions with our comprehensive CRM and automation solution.</p>
                    <h6 class="mt-4">Key Features:</h6>
                    <ul>
                        <li><strong>Lead Management:</strong> Capture, score, and nurture leads through the sales funnel</li>
                        <li><strong>Email Campaigns:</strong> Automated email sequences with A/B testing and analytics</li>
                        <li><strong>Customer Segmentation:</strong> Target audiences based on behavior, demographics, and preferences</li>
                        <li><strong>Social Media Integration:</strong> Schedule posts, monitor engagement, and track ROI</li>
                        <li><strong>Analytics Dashboard:</strong> Real-time insights on campaign performance and customer behavior</li>
                        <li><strong>Sales Pipeline:</strong> Visual pipeline management with automated task assignments</li>
                    </ul>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn-primary-custom">Request Demo</button>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="serviceModal6" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-cloud text-secondary me-2"></i>Cloud & AI Solutions</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <img src="https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=800" alt="Cloud" class="img-fluid rounded mb-3">
                    <h5>Cloud Migration & AI-Powered Analytics</h5>
                    <p>Harness the power of cloud computing and artificial intelligence to transform your business operations.</p>
                    <h6 class="mt-4">Services Include:</h6>
                    <ul>
                        <li><strong>Cloud Migration:</strong> Seamless transition from on-premise to AWS, Azure, or Google Cloud</li>
                        <li><strong>Infrastructure as Code:</strong> Automated provisioning with Terraform and CloudFormation</li>
                        <li><strong>Microservices Architecture:</strong> Scalable, resilient system design with Docker and Kubernetes</li>
                        <li><strong>AI/ML Models:</strong> Predictive analytics, recommendation engines, and natural language processing</li>
                        <li><strong>Big Data Analytics:</strong> Process and analyze large datasets with Spark and Hadoop</li>
                        <li><strong>Security & Compliance:</strong> End-to-end encryption, access control, and regulatory compliance</li>
                    </ul>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn-primary-custom">Request Demo</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
        // Wait for AOS library to load
        window.addEventListener('load', function() {
            // Initialize AOS
            if (typeof AOS !== 'undefined') {
                AOS.init({
                    duration: 1000,
                    once: true,
                    offset: 100
                });
            }
        });

        // Scroll Progress Bar
        window.addEventListener('scroll', () => {
            const winScroll = document.body.scrollTop || document.documentElement.scrollTop;
            const height = document.documentElement.scrollHeight - document.documentElement.clientHeight;
            const scrolled = (winScroll / height) * 100;
            document.getElementById('progressBar').style.width = scrolled + '%';
        });

        // Particle Background
        const particleBg = document.getElementById('particleBg');
        for (let i = 0; i < 50; i++) {
            const particle = document.createElement('div');
            particle.className = 'particle';
            particle.style.width = Math.random() * 5 + 'px';
            particle.style.height = particle.style.width;
            particle.style.left = Math.random() * 100 + '%';
            particle.style.top = Math.random() * 100 + '%';
            particle.style.animationDelay = Math.random() * 20 + 's';
            particle.style.animationDuration = (Math.random() * 20 + 10) + 's';
            particleBg.appendChild(particle);
        }

        // Typewriter Effect
        const typewriter = document.getElementById('typewriter');
        const texts = [
            'Building Smart School Solutions',
            'Transforming Healthcare Technology',
            'Creating Custom Web Apps',
            'Powering Digital Marketing',
            'Enabling Cloud Innovation'
        ];
        let textIndex = 0;
        let charIndex = 0;
        let isDeleting = false;

        function type() {
            const currentText = texts[textIndex];
            
            if (isDeleting) {
                typewriter.textContent = currentText.substring(0, charIndex - 1);
                charIndex--;
            } else {
                typewriter.textContent = currentText.substring(0, charIndex + 1);
                charIndex++;
            }

            if (!isDeleting && charIndex === currentText.length) {
                isDeleting = true;
                setTimeout(type, 2000);
            } else if (isDeleting && charIndex === 0) {
                isDeleting = false;
                textIndex = (textIndex + 1) % texts.length;
                setTimeout(type, 500);
            } else {
                setTimeout(type, isDeleting ? 50 : 100);
            }
        }

        type();

        // Counter Animation
        const counters = document.querySelectorAll('.counter-number');
        const speed = 200;
        let animated = false;

        const animateCounters = () => {
            counters.forEach(counter => {
                const target = +counter.getAttribute('data-target');
                const increment = target / speed;

                const updateCount = () => {
                    const count = +counter.innerText;
                    if (count < target) {
                        counter.innerText = Math.ceil(count + increment);
                        setTimeout(updateCount, 10);
                    } else {
                        counter.innerText = target + '+';
                    }
                };

                updateCount();
            });
        };

        window.addEventListener('scroll', () => {
            if (!animated) {
                const counterSection = document.querySelector('.counter-box');
                if (counterSection) {
                    const rect = counterSection.getBoundingClientRect();
                    if (rect.top < window.innerHeight && rect.bottom >= 0) {
                        animateCounters();
                        animated = true;
                    }
                }
            }
        });

        // Load More Blogs
        const loadMoreBtn = document.getElementById('loadMoreBtn');
        let blogsVisible = false;

        loadMoreBtn.addEventListener('click', () => {
            const extraBlogs = document.querySelectorAll('.blog-extra');
            if (!blogsVisible) {
                extraBlogs.forEach(blog => {
                    blog.style.display = 'block';
                });
                loadMoreBtn.textContent = 'Show Less';
                blogsVisible = true;
            } else {
                extraBlogs.forEach(blog => {
                    blog.style.display = 'none';
                });
                loadMoreBtn.textContent = 'Load More Articles';
                blogsVisible = false;
                document.getElementById('blog').scrollIntoView({ behavior: 'smooth' });
            }
        });

        // Contact Form
      document.getElementById('contactForm').addEventListener('submit', function(e) {
    e.preventDefault(); // Prevent default form submission
    
    // Get form data
    const formData = new FormData(this);
    const submitBtn = this.querySelector('button[type="submit"]');
    const originalBtnText = submitBtn.innerHTML;
    
    // Disable button and show loading state
    submitBtn.disabled = true;
    submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Sending...';
    
    // Remove any previous messages
    const existingAlert = document.querySelector('.alert');
    if (existingAlert) {
        existingAlert.remove();
    }
    
    // Send AJAX request
    fetch('/api/contact', {
        method: 'POST',
        body: formData,
        headers: {
            'X-Requested-With': 'XMLHttpRequest',
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
        }
    })
    .then(response => {
        // Log response for debugging
        console.log('Response status:', response.status);
        return response.json();
    })
    .then(data => {
        console.log('Response data:', data);
        
        // Re-enable button
        submitBtn.disabled = false;
        submitBtn.innerHTML = originalBtnText;
        
        if (data.success) {
            // Show success message
            showMessage('success', data.message);
            
            // Reset form
            document.getElementById('contactForm').reset();
            
            // Optional: Scroll to message
            document.querySelector('.alert').scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        } else if (data.errors) {
            // Handle validation errors
            let errorMessages = Object.values(data.errors).flat().join('\n');
            showMessage('danger', errorMessages);
        }
    })
    .catch(error => {
        console.error('Fetch error:', error);
        
        // Re-enable button
        submitBtn.disabled = false;
        submitBtn.innerHTML = originalBtnText;
        
        // Show error message
        showMessage('danger', 'Oops! Something went wrong. Please try again.');
    });
});

// Function to show beautiful message
function showMessage(type, message) {
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type} alert-dismissible fade show mt-3 animated-alert`;
    alertDiv.innerHTML = `
        <div class="d-flex align-items-center">
            <i class="bi bi-${type === 'success' ? 'check-circle-fill' : 'exclamation-triangle-fill'} me-2 fs-4"></i>
            <div>
                <strong>${type === 'success' ? 'Success!' : 'Error!'}</strong>
                <p class="mb-0">${message}</p>
            </div>
        </div>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    // Insert after form
    const form = document.getElementById('contactForm');
    form.parentNode.insertBefore(alertDiv, form.nextSibling);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        alertDiv.classList.remove('show');
        setTimeout(() => alertDiv.remove(), 150);
    }, 5000);
}

        // Smooth Scroll
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        });

        // Auto-play testimonial carousel
        const testimonialCarousel = new bootstrap.Carousel(document.getElementById('testimonialCarousel'), {
            interval: 5000,
            wrap: true
        });

        // Auto-play case study carousel
        const caseCarousel = new bootstrap.Carousel(document.getElementById('caseCarousel'), {
            interval: 7000,
            wrap: true
        });


        
    // disable right click
   document.addEventListener('contextmenu', e => e.preventDefault());

    // disable selection via keyboard (Shift+Arrow) and Ctrl/Cmd+A
   document.addEventListener('selectstart', e => e.preventDefault());

    // disable common devtools/inspect/view-source keyboard combos
    document.addEventListener('keydown', function(e) {
      // mac support: metaKey is command key
      const ctrl = e.ctrlKey || e.metaKey;
      // Block F12, Ctrl+Shift+I, Ctrl+Shift+J, Ctrl+U, Ctrl+S, Ctrl+Shift+C
      if (e.key === 'F12' ||
          (ctrl && e.shiftKey && (e.key === 'I' || e.key === 'J' || e.key === 'C')) ||
          (ctrl && e.key === 'U') ||
          (ctrl && e.key === 'S')) {
        e.preventDefault();
        e.stopPropagation();
      }
    }, true);

    // disable copy, cut, paste via context and keyboard
    ['copy','cut','paste'].forEach(evt => {
      document.addEventListener(evt, e => e.preventDefault());
    });
  
    </script>

<script>
    let slideIndex = 0;
    const slides = document.querySelectorAll('.hero-image-slider .slide');

    function changeSlide() {
        slides.forEach(slide => slide.classList.remove('active'));
        slideIndex = (slideIndex + 1) % slides.length;
        slides[slideIndex].classList.add('active');
    }

    setInterval(changeSlide, 3600); // Change image every 3.6 seconds
</script>



</body>
</html><?php /**PATH /media/developer/New Volume/arambh-tech/School-Erp/auth-service/resources/views/welcome.blade.php ENDPATH**/ ?>