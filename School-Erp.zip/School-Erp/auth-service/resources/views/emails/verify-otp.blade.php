<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verify Your Email</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 600px;
            margin: 0 auto;
            background-color: #ffffff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        .header {
            text-align: center;
            background-color: #007bff;
            color: white;
            padding: 20px;
            border-radius: 8px 8px 0 0;
        }
        .otp-code {
            font-size: 32px;
            font-weight: bold;
            color: #007bff;
            background-color: #f8f9fa;
            padding: 15px 25px;
            border-radius: 8px;
            display: inline-block;
            margin: 20px 0;
            letter-spacing: 5px;
            border: 2px dashed #007bff;
        }
        .info {
            background-color: #fff3cd;
            border: 1px solid #ffeaa7;
            padding: 15px;
            border-radius: 5px;
            margin: 20px 0;
            color: #856404;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>School ERP</h1>
            <p>Email Verification Required</p>
        </div>
        
        <div style="padding: 30px 20px; text-align: center;">
            <h2>Hello {{ $userName }}!</h2>
            <p>Thank you for registering with our School ERP system. Please verify your email address using the code below:</p>
            
            <div class="otp-code">{{ $otp }}</div>
            
            <div class="info">
                <strong>Important:</strong> This code will expire in <strong>10 minutes</strong>.
            </div>
            
            <p>Enter this code in the verification form to activate your account.</p>
            
            <div style="background-color: #d1ecf1; border: 1px solid #bee5eb; padding: 15px; border-radius: 5px; color: #0c5460; text-align: left;">
                <h4>Security Tips:</h4>
                <ul>
                    <li>Never share this code with anyone</li>
                    <li>If you didn't request this verification, please ignore this email</li>
                    <li>This code can only be used once</li>
                </ul>
            </div>
        </div>
        
        <div style="text-align: center; color: #6c757d; font-size: 12px; margin-top: 30px; padding-top: 20px; border-top: 1px solid #dee2e6;">
            <p>This is an automated message from School ERP System.</p>
        </div>
    </div>
</body>
</html>