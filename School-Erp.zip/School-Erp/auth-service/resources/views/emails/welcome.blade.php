<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to School ERP</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 600px;
            margin: 0 auto;
            background-color: #ffffff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        .header {
            text-align: center;
            background: linear-gradient(135deg, #28a745, #20c997);
            color: white;
            padding: 30px 20px;
            border-radius: 8px 8px 0 0;
        }
        .role-badge {
            display: inline-block;
            padding: 5px 10px;
            background-color: #007bff;
            color: white;
            border-radius: 15px;
            font-size: 12px;
            font-weight: bold;
            text-transform: uppercase;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Welcome to School ERP!</h1>
            <p>Your account is now active and verified</p>
        </div>
        
        <div style="padding: 30px 20px;">
            <div style="background-color: #d4edda; border: 1px solid #c3e6cb; padding: 20px; border-radius: 8px; margin: 20px 0; color: #155724;">
                <h2>Congratulations {{ $user->name }}!</h2>
                <p>Your email has been successfully verified and your account is now active.</p>
            </div>
            
            <div style="background-color: #f8f9fa; border: 1px solid #dee2e6; padding: 15px; border-radius: 5px; margin: 20px 0;">
                <h3>Your Account Details:</h3>
                <ul>
                    <li><strong>Name:</strong> {{ $user->name }}</li>
                    <li><strong>Email:</strong> {{ $user->email }}</li>
                    <li><strong>Username:</strong> {{ $user->username }}</li>
                    <li><strong>Role:</strong> <span class="role-badge">{{ ucfirst($user->role) }}</span></li>
                    @if($user->school_id)
                    <li><strong>School ID:</strong> {{ $user->school_id }}</li>
                    @endif
                </ul>
            </div>
            
            <p style="text-align: center;">You can now login to your account and start using the School ERP system.</p>
        </div>
        
        <div style="text-align: center; color: #6c757d; font-size: 12px; margin-top: 30px; padding-top: 20px; border-top: 1px solid #dee2e6;">
            <p><strong>School ERP System</strong></p>
            <p>This is an automated welcome message.</p>
        </div>
    </div>
</body>
</html>