<!DOCTYPE html>
<html>
<head>
    <title>Password Reset OTP</title>
</head>
<body>
    <h2>Password Reset Request</h2>
    <p>Hello {{ $userName }},</p>
    <p>You requested a password reset. Your OTP is:</p>
    <h3 style="color: #007bff; font-size: 24px;">{{ $otp }}</h3>
    <p>This code will expire in 10 minutes.</p>
    <p>If you didn't request this, please ignore this email.</p>
</body>
</html>